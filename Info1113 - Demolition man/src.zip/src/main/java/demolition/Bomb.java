package demolition;
import java.util.HashMap;
import processing.core.PImage;
import processing.core.PApplet;
import java.util.ArrayList;
import java.util.List;

/**
Manages bomb objects within game.
*/
public class Bomb extends Moving{
    /**
    Timer indicating when the bomb will detonate and explode. 
    */
    private int timer ;  
    /**
    Iterator keeps track of the animation
    */
    private int iterator;
    /**
    HashMap storing the the animation and its associated PImage files. 
    */
    private static HashMap<String, PImage[]> animations = new HashMap<String, PImage[]>();
    /**
    Arraylist of bombs which are currently still active  (detonated, counting down or exploding).
    */
    private static ArrayList<Bomb> bombs = new ArrayList<Bomb>();
    /**
    Holds the current level map.
    */
    private Map map;
    /**
    Arraylist of locations where bombs are currently exploding. The Arraylist carries an array of the image type of the explosion, the x and the y position on the map. 
    */
    private ArrayList<int[]> explosion = new ArrayList<int[]>(); // image tyoe, x, y
    /**
    Indicates whether the bomb has exploded yet.
    */
    private boolean exploded = false;

    /**
    *Creates a new Bomb on the map and adds the bomb to the static list of active bombs. 
    *@param x This is the x value of the bomb
    *@param y This is the y value of the bomb
    *@param map This is the map where the bomb is placed
    */
    public Bomb(int x, int y, Map map){
        super(x,y);
        setFirstSprite();
        this.timer = 0;
        this.map = map;
        Bomb.bombs.add(this);
    }


    private void setFirstSprite(){
        if (this.animations.size()!= 0){
            this.setSprite(this.animations.get("place")[0]);
        }else{
            System.err.println("Error: Set animations first with setAnimations()");
        }
    }

    /**
    *Sets the animations for the Bomb class. These are held in the static Hashmap which has one animation array for the bomb placement and one animation array for the explosions. 
    *@param app The app you are drawing in 
    */
    public static void setAnimations(PApplet app){
        // Loading Bomb animations
        PImage Bomb1 = app.loadImage("src/main/resources/bomb/bomb.png");
        PImage Bomb2 = app.loadImage("src/main/resources/bomb/bomb1.png");
        PImage Bomb3 = app.loadImage("src/main/resources/bomb/bomb2.png");
        PImage Bomb4 = app.loadImage("src/main/resources/bomb/bomb3.png");
        PImage Bomb5 = app.loadImage("src/main/resources/bomb/bomb4.png");
        PImage Bomb6 = app.loadImage("src/main/resources/bomb/bomb5.png");
        PImage Bomb7 = app.loadImage("src/main/resources/bomb/bomb6.png");
        PImage Bomb8 = app.loadImage("src/main/resources/bomb/bomb7.png");
        PImage Bomb9 = app.loadImage("src/main/resources/bomb/bomb8.png");

        PImage[] bombPlacement = new PImage[]{Bomb1,Bomb2,Bomb3,Bomb4,Bomb5,
                                                Bomb6,Bomb7,Bomb8,Bomb9,};
        
        PImage explode1 = app.loadImage("src/main/resources/explosion/centre.png");
        PImage explode2 = app.loadImage("src/main/resources/explosion/horizontal.png");
        PImage explode3 = app.loadImage("src/main/resources/explosion/vertical.png");
        PImage explode4 = app.loadImage("src/main/resources/explosion/end_left.png");
        PImage explode5 = app.loadImage("src/main/resources/explosion/end_right.png");
        PImage explode6 = app.loadImage("src/main/resources/explosion/end_top.png");
        PImage explode7 = app.loadImage("src/main/resources/explosion/end_bottom.png");

        PImage[] explosions = new PImage[]{explode1,explode2, explode3, explode4, 
                                            explode5, explode6, explode7};

        HashMap<String, PImage[]> bombAnimations = new HashMap<String, PImage[]>();
        bombAnimations.put("place", bombPlacement);
        bombAnimations.put("explode", explosions);
        Bomb.animations = bombAnimations;
    }


    /**
    *Gets the explosion zone of the bomb. 
    *@return  This returns an arraylist which holds an array of the animation type, x and y value for the explosion zone of the bomb. 
    */
    public ArrayList<int[]> getExplosionZone(){
        return this.explosion;
    }

    /**
    Indicates whether the bomb has exploded
    @return boolean True if exploded and false if not exploded 
    */
    public boolean exploded(){
        return this.exploded;
    }
    /**
    Cleans the current arraylist of active bombs by removing the ones which have exploded 
    */
    public static void removeBomb(){
        Bomb.bombs.removeIf(i -> i.exploded() == true);
    }

    /**
    Gets the current list of active bombs. 
    @return  This returns an arraylist of the active bombs. 
    */
    public static ArrayList<Bomb> getBombs(){
        return Bomb.bombs;
    }

    /**
    Draws the bomb's current state
    @param app The app which you are drawing in.
    */
    public void draw(PApplet app){ //overwtie draw so that it uses the offset
        if(timer>2.5*App.FPS){
            ;
        }
        else{
        app.image(this.sprite, this.getX(), this.getY()+16);
        if (this.explosion.size()!= 0){
            // Iterates through eveyr single explosion 
            for(int[] explosionAnimation: explosion){
                app.image(this.animations.get("explode")[explosionAnimation[0]], explosionAnimation[1], explosionAnimation[2]+16); // + 16 since all images are currently lined up with the top left corner of player images.
                }
            }   
        }
    }

    /**
    Draws all the bombs currently active and removes any bombs which have exploded afterwards 
    @param app The app which you are drawing in.
    */
    public static void drawBombs(PApplet app) {
        if(Bomb.getBombs()!= null){
            for (Bomb bomb: Bomb.getBombs()){
                bomb.draw(app);
            }
            Bomb.removeBomb();
        }else{
            return; 
        } 
    }

    /**
    *Moves the bomb foward by one frame. Will handle the current animation for the bombs state, detonates the bomb at 2 seconds and indicates the bomb has exploded at 2.5 seconds. 
    */
    public void tick(){
        this.timer++;
        if (this.timer == 2.5*App.FPS){
            this.exploded = true;
        } else if(this.timer == 2*App.FPS){
            this.detonate();
        }else{
            // Every 4 s
            if(this.timer%15 == 0 && this.timer<2*App.FPS){
                this.iterator++;
                if (this.animations.size()!= 0){
                    this.setSprite(this.animations.get("place")[this.iterator]);
                }else{
                    System.err.println("Error: Set animations first with setAnimations()");
                }
            }
        }
    }

    /**
    *Goes through each active bomb and moves it ahead by one frame
    *@return  Returns the explosion zone of all the exploding bombs. This is an arraylist with an integer array holding the animation type, x and y location.
    */
    public static ArrayList<int[]> explode(){
        ArrayList<int[]> explosionZone = new ArrayList<int[]>();
            // Onlygets bombs currently active and iterates through those 
            if(Bomb.getBombs().size()!= 0){
                for (Bomb bomb: Bomb.getBombs()){
                    bomb.tick();
                    explosionZone.addAll(bomb.getExplosionZone());
                }
                return explosionZone;

            // Otherwise, there are no explosion zones
            }else{
                return explosionZone; 
            }
    }


    // FIgures out where the bomb can detonate 
    private void detonate(){

        // Adds the bombs current locaiton 
        this.explosion.add(new int[]{0, this.x, this.y}); 
        // If up works, try up again 
        if (detonateHelper("up",0, -1, 1, 2) == true){
            detonateHelper("up",0, -1, 2, 5);
        }
        // If down works, try down again 

        if (detonateHelper("down",0, 1, 1, 2) == true){
            detonateHelper("down",0, 1, 2, 6);
        }
        // If left works, try left again 
        if (detonateHelper("left",-1, 0, 1, 1) == true){
            detonateHelper("left",-1, 0, 2, 3);
        }
        // If right works, try right again 
        if (detonateHelper("right",1, 0, 1, 1) == true){
            detonateHelper("right",1, 0, 2, 4);
        }
        // Add the bombs current location!
    }


    // Adds the explosion zone for the bomb if there is no wall in that locaion 
    private boolean detonateHelper(String dir, int x, int y, int width, int animationNo){
        int xOffset = this.x+32*x*width;
        int yOffset = this.y+32*y*width;

        // If this new direction away from the bomb doesnt have a wall 
        if (this.checkForWalls(dir, width) == false){

            // Create a list for the animation type and the locaiton and add it to the explosion zone 
            int[] notes = new int[]{animationNo,xOffset, yOffset};
            this.explosion.add(notes);  

            // So we know if we should check the next one 
            return true;
        // Or if theres a broken wall
        } else if (this.map.getTile(xOffset, yOffset) == tiletypes.broken){
            // Add the explosion zone 
            int[] notes = new int[]{animationNo,xOffset, yOffset};
            this.explosion.add(notes);  

            // Remove the broken wall from the map and update from current walls 
            this.map.removeBrokenWall(xOffset, yOffset);
            this.setMapWalls(this.map.getWalls());
            
            // We cant check the next consquential tile 
            return false;
        }
        return false; 
        
    }



}