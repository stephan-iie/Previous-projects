package demolition;
import java.util.HashMap;
import processing.core.PImage;
import java.util.ArrayList;

/**
*Abstract class for enemy types
*/ 
public abstract class Enemies extends Person{

    private boolean dead = false;
    private String type;
    /**
    *Timer to indicate how many seconds has passed 
    */ 
    protected int movingTimer = 0;

    /**
    *Initialises the enemy x and y coordinates, sets the enemy type, sets animation as moving downwards.
    *@param x x coordinate 
    *@param y y coordinate 
    *@param type String type of enemy. "Red" or "Yellow".
    */ 
    public Enemies(int x, int y, String type){
        super(x,y);
        this.type = type;
        this.moveLR = 0;
        this.moveUD = 0;
        this.animationCycle="down";

    }

    /**
    *Gets the type of enemy 
    *@return String being either red or yellow
    */ 
    public String getType(){
        return this.type;
    }

    /**
    *Abstract method to determine the way the enemy object chooses its next direction 
    */ 
    protected abstract void DirectionChange();

    /**
    *Checks whether the player has met any of the enemies 
    *@param x x coordinate of player 
    *@param y y coordinate of player 
    *@param enemies Arraylist of enemies
    *@return True if player has met an enemy and false otherwise 
    */ 
    public static boolean enemyMet(int x, int y, ArrayList<Enemies> enemies){

        if(enemies == null ||enemies.size() == 0 ){
            return false;
        }

        for (Enemies e: enemies ){

            if (x == e.getX() && y == e.getY()){
                return true;
            }
        }
        return false;
    }

    /**
    *Kills the enemy object 
    */ 
    public void killEnemy(){
        this.dead = true;
    }

    /**
    *Indicates if the enemy object has been killed
    *@return True if killed and false if not killed
    */ 
    public boolean enemyKilled(){
        return this.dead;
    }

    /**
    *Gets the current animation cycle of the enemy object
    *@return String being either "up", "down", "left", "right"
    */ 
    public String getAnimationCycle(){
        return this.animationCycle;
    }
    

}