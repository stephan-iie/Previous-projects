// Redners map 

package demolition;


import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;


import processing.core.PImage;
import processing.core.PApplet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
*Class reads in, manages and saves the current level map. 
*/
public class Map{
 
    private tiletypes[][] map;
    private String level;
    private int[] start = new int[]{-1,-1};
    private int[] goal = new int[]{-1,-1};
    private ArrayList<int[]> enemiesR = new ArrayList<int[]>();
    private ArrayList<int[]> enemiesY = new ArrayList<int[]>();
    private HashMap<String, int[]> walls = new HashMap<String, int[]>();


    /**
    *Loads in the level map and initialises array object to store tiles
    *@param levelPath Path to level map 
    */    
    public Map(String levelPath){
        this.level = levelPath;
        this.map = new tiletypes[13][15];
    }

    /**
    *Gets the map array of tiletypes 
    *@return Matrix of tiletypes array 
    */    
    public tiletypes[][] getMapArray(){
        return this.map;
    }

    /**
    *Gets the starting location of the player 
    *@return int[] with the x and y locations of the starting player coordinates  
    */  
    public int[] getPlayerStart(){
        return start;
    }

    /**
    *Gets the start locations of all red enemies 
    *@return Arraylist of x and y coordinates for all red enemies on the map, each stored in an integer array
    */  
    public ArrayList<int[]> getEnemiesRStart(){
        return this.enemiesR; 
    }

    /**
    *Gets the start locations of all yellow enemies 
    *@return Arraylist of x and y coordinates for all yellow enemies on the map, each stored in an integer array
    */  
    public ArrayList<int[]> getEnemiesYStart(){
        return this.enemiesY; 
    }

    /**
    *Gets the x and y coordinates of broken and solid walls on the map. These are stored with the string format "x,y" being the key with the associated value being the coordinates in an integer array.
    *@return Hashmap of x and y coordinates of all solid and broken walls still standing in the map
    */ 
    public HashMap<String, int[]> getWalls(){
        return this.walls;
    }
    
    /**
    *Gets the goal location
    *@return int[] with the x and y locations of the goal coordinates  
    */ 
    public int[] getFinish(){
        return this.goal;
    }

    /**
    *Removes a wall broken by the players bomb  
    *@param x x coordinate of the wall
    *@param y y coordinate of the wall
    */ 
    public void removeBrokenWall(int x, int y){
        int row = (y-48)/32;
        int col = x/32;
        if(this.map[row][col] == tiletypes.broken){
            this.map[row][col] = tiletypes.empty; //for rednering map 
            this.walls.remove(String.format("%d,%d",x, y)); // for later enemy moves 
        }
    }
    
    /**
    *Gets the tiletype at the associated x and y location 
    *@param x x coordinate
    *@param y y coordinate
    *@return Returns the tiletype, see the tiletype enum for more information. 
    */ 
    public tiletypes getTile(int x, int y){
        if (x<0 || x>448 || y<0 || y>448){
            return tiletypes.solid;
        }
        int row = (y-48)/32;
        int col = x/32;
   
        return this.map[row][col];
    }

    // Function which converts between between letters to tiles everytime a map is imported, adds the identifier to the list of walls if solid or broken tile and updates start and goal positions 
    private tiletypes convertTiles(char letter, int row, int col){
        if (letter == 'W'){
            int[] location = new int[]{col*32,48+row*32};
            String identifier = String.format("%d,%d", col*32, 48+row*32);
            this.walls.put( identifier, location);
            return tiletypes.solid ;

        } else if (letter =='B'){
            int[] location = new int[]{col*32,48+row*32};
            String identifier = String.format("%d,%d", col*32, 48+row*32);
            this.walls.put(identifier, location);
            return tiletypes.broken; 

        } else if (letter == 'G'){
            this.goal[0] = col*32;
            this.goal[1] = 48+row*32;
            return tiletypes.goal; 

        } else if (letter == ' '){
            return tiletypes.empty;

        } else if (letter =='R'){ 
            int[] location = new int[]{col*32,48+row*32};
            enemiesR.add(location);
            return tiletypes.empty;

        } else if (letter =='Y'){ 
            int[] location = new int[]{col*32,48+row*32};
            enemiesY.add(location);
            return tiletypes.empty;

        } else {
            start[0] = col*32;
            start[1] = 48+row*32;
            return tiletypes.empty;
        }
    }

    /**
    *Read from the given path and store into our map object.
    *@exception IncorrectMap thrown if map is in the incorrect format, i.e. too many columns, too many rows, no goal or start and etc. 
    */ 
    public void importMap() throws IncorrectMap {

        // Used to determine if the map is bounded 
        int wallsStartColumns = 15;
        int wallsEndColumns = -1;

        int wallsStartRows = 13;
        int wallsEndRows = -1;


        File f = new File(this.level);        
        try{
            Scanner scan = new Scanner(f);

            int rowN = 0; // Will go 1-13 in the loop

            while (scan.hasNextLine()){ 
                rowN++;
                // check it matches requiremetns for hegiht and width 
                if (rowN >13){
                    throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - Too many rows");
                }

                String line = scan.nextLine();

                if (line.length()>15){
                    // create your own excpetion 
                    throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - Too many columns");
                }

                if(line.length()<15){
                    throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - Not enough columns");
                }

                for(int i = 0; i<15; i++){
                    this.map[rowN-1][i]= convertTiles(line.charAt(i) , rowN-1, i);

                    // Check if its the starting or ending of the row of walls 
                    if(this.map[rowN-1][i] == tiletypes.solid && rowN-1 <wallsStartRows ){
                        wallsStartRows = rowN-1;
                    }
                    else if (this.map[rowN-1][i] == tiletypes.solid && rowN-1 >wallsEndRows){
                        wallsEndRows = rowN-1;
                    }

                    // Check if its the staritng or ending of the wall olumns 
                    if(this.map[rowN-1][i] == tiletypes.solid && i <wallsStartColumns ){
                        wallsStartColumns = i;
                    }
                    else if (this.map[rowN-1][i] == tiletypes.solid && i >wallsEndRows){
                        wallsEndColumns = i;
                    }



                }
                
            }
            if (rowN<13){
                throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - Not enough rows");
            }

            // Check there is a start and goal location 
            if (this.start[0] == -1 && this.start[1] == -1 ){
                throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - No starting location for player");
            }
            if ( this.goal[0] == -1 && this.goal[1] == -1){
                System.err.println(Arrays.toString(this.goal));
                throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - No goal");
            }

            int startRow = (this.start[1]-48)/32;
            int startCol = this.start[0]/32;
            int goalRow = (this.goal[1]-48)/32;
            int goalCol = this.goal[0]/32;

            // Check it is bounded
            if (wallsStartRows  == 13 || wallsEndRows == -1 ){ // Happens if no solid wall at al 
                throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - No solid walls");
            }
            // Checks valid starting points and goal points (within boudnareis )
            if(startRow<wallsStartRows || startRow>wallsEndRows ){
                throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - Starting location not in walls");
            }
            if(goalRow<wallsStartRows || goalRow>wallsEndRows ){
                throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - Goal location not in walls");
            }

            if(startCol<wallsStartColumns || startCol>wallsEndColumns ){
                throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - Starting location not in walls");
            }
            if(goalCol<wallsStartColumns || goalCol>wallsEndColumns ){

                throw new IncorrectMap("ERROR: INCORRECT MAP FORMAT - Goal location not in walls");
            }



        } catch (FileNotFoundException e){
            throw new IncorrectMap("ERROR: File issue");
        }

    }


    /**
    *Renders the maps current state 
    *@param app The app which you would like to draw in 
    */ 
    public void draw(PApplet app){

        
        int ystart = 64;
        
        for (int row = 0; row <= 12; row ++){
            int xstart = 0; // for every row, we start back at left side 
            for (int col = 0; col <= 14; col ++){
                PImage sprite = Tiles.getSprite(this.map[row][col] );
                app.image(sprite,xstart, ystart);
                xstart +=32; // incrememnt x as we go through columns 
            }
            ystart += 32; // shift down after eveyr row 
           
        } 

    }
}
