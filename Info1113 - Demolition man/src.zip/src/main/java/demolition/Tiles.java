package demolition;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

import processing.core.PApplet;
import processing.core.PImage;
import processing.data.JSONObject;
import processing.data.JSONArray;

import java.util.HashMap;
import java.util.List;

/**
*Class managing different game tiles by storing the associated tiletype with its associated PImage object
*/
public class Tiles{
    /**
    *HashMap storing the tiletype and its associated PImage object
    */
    private static HashMap <tiletypes, PImage> tileImages = new HashMap<tiletypes, PImage>();
    private static tiletypes sol = tiletypes.solid;
    private static tiletypes bro = tiletypes.broken;
    private static tiletypes emp = tiletypes.empty;
    private static tiletypes go = tiletypes.goal;

 
    /**
    *Loads the associated images into a static Hashap of the Tiles and their associated image.
    *@param app The app which you want to draw in 
    */
    public  static void setTiles(PApplet app){
        // Load images during setup
        PImage wsolid = app.loadImage("src/main/resources/wall/solid.png");
        PImage wbroken = app.loadImage( "src/main/resources/broken/broken.png");
        PImage wempty = app.loadImage("src/main/resources/empty/empty.png");
        PImage wgoal = app.loadImage("src/main/resources/goal/goal.png");

        tileImages.put(sol, wsolid);
        tileImages.put(bro, wbroken);
        tileImages.put(emp, wempty);
        tileImages.put(go, wgoal);
    }

/**
*Function returns the PImage object associated with the Tile. Tiles come from the tiletypes enum.
*@param tile from tiletypes enum
*@return PImage associated with tiletype
*/
    public static PImage getSprite(tiletypes tile){
        return tileImages.get(tile);
    }

}
