package demolition;

class IncorrectMap extends RuntimeException{
    public IncorrectMap(String errorMsg){
        super(errorMsg);
    }

}


class levelSetupIssue extends RuntimeException{
    public levelSetupIssue(String msg){
        super(msg);
    }
}