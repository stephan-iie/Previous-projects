package demolition;
import java.util.HashMap;
import processing.core.PImage;
import processing.core.PApplet;

import java.util.ArrayList;


/**
*Manages state and movements of red enemies
*/ 
public class RedEnemy extends Enemies{

    private static HashMap<String, PImage[]> animations = new HashMap<String, PImage[]>();

    /**
    *Initialises enemy object with the red type 
    *@param x x coordinate
    *@param y y coordinate    
    */ 
    public RedEnemy(int x, int y){
        super(x,y, "Red");
    }

   /**
    *Sets the animations for red enemy objects
    *@param app The app you want to display the object in
    */ 
    public static void setAnimations(PApplet app){

        // Load Enemy animations during setup
        PImage Rup1 = app.loadImage("src/main/resources/red_enemy/red_up1.png");
        PImage Rup2 = app.loadImage( "src/main/resources/red_enemy/red_up2.png");
        PImage Rup3 = app.loadImage("src/main/resources/red_enemy/red_up3.png");
        PImage Rup4 = app.loadImage("src/main/resources/red_enemy/red_up4.png");

        PImage Rleft1 = app.loadImage("src/main/resources/red_enemy/red_left1.png");
        PImage Rleft2 = app.loadImage("src/main/resources/red_enemy/red_left2.png");
        PImage Rleft3 = app.loadImage("src/main/resources/red_enemy/red_left3.png");
        PImage Rleft4 = app.loadImage("src/main/resources/red_enemy/red_left4.png");

        PImage Rright1 = app.loadImage("src/main/resources/red_enemy/red_right1.png");
        PImage Rright2 = app.loadImage("src/main/resources/red_enemy/red_right2.png");
        PImage Rright3 = app.loadImage("src/main/resources/red_enemy/red_right3.png");
        PImage Rright4 = app.loadImage("src/main/resources/red_enemy/red_right4.png");

        PImage Rdown1 = app.loadImage("src/main/resources/red_enemy/red_down1.png");
        PImage Rdown2 = app.loadImage("src/main/resources/red_enemy/red_down2.png");
        PImage Rdown3 = app.loadImage("src/main/resources/red_enemy/red_down3.png");
        PImage Rdown4 = app.loadImage("src/main/resources/red_enemy/red_down4.png");


        PImage[] walkUp = new PImage[] {Rup1, Rup2, Rup3, Rup4};
        RedEnemy.animations.put("up", walkUp);
        PImage[] walkLeft = new PImage[] {Rleft1, Rleft2, Rleft3, Rleft4};
        RedEnemy.animations.put("left", walkLeft);
        PImage[] walkRight = new PImage[] {Rright1, Rright2, Rright3, Rright4};
        RedEnemy.animations.put("right", walkRight);
        PImage[] walkDown = new PImage[] {Rdown1, Rdown2, Rdown3, Rdown4 };
        RedEnemy.animations.put("down", walkDown);
    }


    /**
    *Moves object one frame foreward. This will check the enemy is not approaching a wall, changes directions randomly if needed and moves the object every second. 
    */ 
    public void tick(){
        this.timer++;
        this.movingTimer++;
        if (this.checkForWalls(this.animationCycle,1) == true){ // theres a wall 
            this.DirectionChange();            
        }
        if (this.animations.size()!= 0){
            this.walk(this.animations.get(this.animationCycle));
        } else{
            System.err.println("Error: No animations set, please call setAnimations() in app setup.");
        }
        if (this.movingTimer> 1 * App.FPS){
            if (this.animationCycle == "up"){
                this.y-= 32;
            } else if(this.animationCycle == "down"){
                this.y+= 32;
            }else if(this.animationCycle == "left"){
                this.x-= 32;
            }else if(this.animationCycle == "right"){
                this.x+= 32;
            }
            this.movingTimer= 0;
        }

    }


    /**
    *Chooses a random direction for the enemy to move into out of all the unblocked paths 
    */ 
    protected void DirectionChange(){ 
        // Find out how many directions are availabel 
        ArrayList<String> availableDirections= new ArrayList<String>();
        if (this.checkForWalls( "left",1) == false){
            availableDirections.add("left");
        }
        if (this.checkForWalls("right",1) == false){
            availableDirections.add("right");
        }
        if (this.checkForWalls("up",1) == false){
            availableDirections.add("up");
        }
        if (this.checkForWalls( "down",1) == false){
            availableDirections.add("down");
        }
        

        // random direction from 0-3: 0,1 is Left, right, 2,3 is up donw 
        int randomDirection = (int)Math.floor(Math.random()*availableDirections.size());

        String newDirection = availableDirections.get(randomDirection);
        this.animationCycle = newDirection;

    }
    

}