package demolition;
import java.util.HashMap;
import processing.core.PImage;
import processing.core.PApplet;

/**
*Manages state and movements of yellow enemies
*/ 
public class YellowEnemy extends Enemies{

    private static HashMap<String, PImage[]> animations = new HashMap<String, PImage[]>();

    
    /**
    *Initialises enemy object with the yellow type 
    *@param x x coordinate
    *@param y y coordinate    
    */ 
    public YellowEnemy(int x, int y){
        super(x,y, "Yellow");
    }

    /**
    *Sets the animations for yellow enemy objects
    *@param app The app you want to display the object in
    */ 
    public static void setAnimations(PApplet app){
        // Load Enemy animations during setup
        PImage Yup1 = app.loadImage("src/main/resources/yellow_enemy/yellow_up1.png");
        PImage Yup2 = app.loadImage( "src/main/resources/yellow_enemy/yellow_up2.png");
        PImage Yup3 = app.loadImage("src/main/resources/yellow_enemy/yellow_up3.png");
        PImage Yup4 = app.loadImage("src/main/resources/yellow_enemy/yellow_up4.png");

        PImage Yleft1 = app.loadImage("src/main/resources/yellow_enemy/yellow_left1.png");
        PImage Yleft2 = app.loadImage("src/main/resources/yellow_enemy/yellow_left2.png");
        PImage Yleft3 = app.loadImage("src/main/resources/yellow_enemy/yellow_left3.png");
        PImage Yleft4 = app.loadImage("src/main/resources/yellow_enemy/yellow_left4.png");

        PImage Yright1 = app.loadImage("src/main/resources/yellow_enemy/yellow_right1.png");
        PImage Yright2 = app.loadImage("src/main/resources/yellow_enemy/yellow_right2.png");
        PImage Yright3 = app.loadImage("src/main/resources/yellow_enemy/yellow_right3.png");
        PImage Yright4 = app.loadImage("src/main/resources/yellow_enemy/yellow_right4.png");

        PImage Ydown1 = app.loadImage("src/main/resources/yellow_enemy/yellow_down1.png");
        PImage Ydown2 = app.loadImage("src/main/resources/yellow_enemy/yellow_down2.png");
        PImage Ydown3 = app.loadImage("src/main/resources/yellow_enemy/yellow_down3.png");
        PImage Ydown4 = app.loadImage("src/main/resources/yellow_enemy/yellow_down4.png");


        PImage[] walkUp = new PImage[] {Yup1, Yup2, Yup3, Yup4};
        YellowEnemy.animations.put("up", walkUp);
        PImage[] walkLeft = new PImage[] {Yleft1, Yleft2, Yleft3, Yleft4};
        YellowEnemy.animations.put("left", walkLeft);
        PImage[] walkRight = new PImage[] {Yright1, Yright2, Yright3, Yright4};
        YellowEnemy.animations.put("right", walkRight);
        PImage[] walkDown = new PImage[] {Ydown1, Ydown2, Ydown3, Ydown4};
        YellowEnemy.animations.put("down", walkDown);
    }

    /**
    *Moves object one frame foreward. This will check the enemy is not approaching a wall, changes directions clockwise and moves the object every second. 
    */ 
    public void tick(){
    this.timer++;
    this.movingTimer++;
    if (this.checkForWalls(this.animationCycle,1)  == true){ // theres a wall 
        this.DirectionChange();            
    }
    if (this.animations.size()!=0){
        this.walk(this.animations.get(this.animationCycle));
    } else{
        System.err.println("Error: No animations set, please call setAnimations() in app setup.");
    }
    if (this.movingTimer> 1 * App.FPS){
        if (this.animationCycle  == "up" && this.checkForWalls("up",1)  == false){
            this.y-=32;
        } else if(this.animationCycle  == "down" && this.checkForWalls("down",1)  == false){
            this.y+=32;
        }else if(this.animationCycle  == "left" && this.checkForWalls("left",1)  == false){
            this.x-=32;
        }else if(this.animationCycle  == "right" && this.checkForWalls("right",1)  == false){
            this.x+=32;
        }
        this.movingTimer=0;
    }

    }
    /**
    *Changes the direction of the enemy to the next clockwise direction 
    */ 
    protected void DirectionChange(){

        if (this.animationCycle  == "left"){
            this.animationCycle="up";
        }
        else if (this.animationCycle  == "right"){
            this.animationCycle="down";
        }
        else if (this.animationCycle  == "up"){
            this.animationCycle="right";
        }
        else if (this.animationCycle=="down"){
            this.animationCycle="left";
        }
        

    }

    /**
    *Sets the animation cycle of the yellow enemy
    *@param cycle String of direction, i.e. "up", "down", "left", "right"
    */ 
    public void setAnimationCycle(String cycle){
        if(cycle.equals("up") || cycle.equals("down")|| cycle.equals("left")|| cycle.equals("right")){
            this.animationCycle = cycle;
        }
    }


    

}