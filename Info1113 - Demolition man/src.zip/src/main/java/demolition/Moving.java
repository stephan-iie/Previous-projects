package demolition;
import processing.core.PImage;
import processing.core.PApplet;
import java.util.HashMap;

/**
*Abstract class for all moving objects in the game
*/ 
public abstract class Moving{
    /**
    *Sprite of the object 
    */ 
    protected PImage sprite;
    /**
    *x coordinate
    */ 
    protected int x;
    /**
    *y coordinate
    */ 
    protected int y; 
    /**
    *HashMap storing the walls in the map
    */ 
    protected static HashMap<String, int[]> walls; 
    /**
    *Indicates if there is an attempt to move left (-1) or right (+1)
    */ 
    protected int moveLR;
    /**
    *Indicates if there is an attempt to move down (-1) or up (+1)
    */ 
    protected int moveUD;


    /**
    *Initialises object at x and y coordinate on the map 
    *@param x x coordinate of moving object
    *@param y y coordinate of moving object 
    */ 
    public Moving(int x, int y){
        this.x = x;
        this.y = y;
    }

    /**
    *Abstract method which moves the object one frame forward
    */ 
    public abstract void tick();

    /**
    *Draws the moving objects current state
    *@param app The app you want to draw the object in 
    */ 
    public void draw(PApplet app){
        app.image(this.sprite, this.x, this.y);
    }

    /**
    *Sets the sprite of the object 
    *@param sprite PImage of the associated sprite 
    */ 
    public void setSprite(PImage sprite){
        this.sprite  = sprite;
    }

    /**
    *Gets the x location of the moving object 
    *@return x coordinate of the object  
    */ 
    public int getX(){
        return this.x;
    }

   /**
    *Gets the y location of the moving object 
    *@return y coordinate of the object  
    */ 
    public int getY(){
        return this.y;
    }


    /**
    *Sets the walls of the map which the moving objet interacts with
    *@param walls HashMap of String format of wall coordinates and the actual x and y coordinates of solid and broken walls in the map. Use with the map.getWalls function(). 
    */ 
    public static void setMapWalls(HashMap<String, int[]> walls){
        Person.walls = walls;
    }

    /**
    *Checks if attempting to move in a certain direction for a number of tiles will encounter a wall. The object will incrementally try to move further in that direction, e.g. checking one position right before checking two positions to the right. 
    *@param direction String of direction to move in. Valid inputs include "up", "down", "left", "right"
    *@param width Integer of how far the object wants to try and move
    *@return True if a wall blocks the path and false if there are no walls blocking the path
    */ 
    public boolean checkForWalls(String direction, int width){
        if (direction.equals("left")){
            String identifier = String.format("%d,%d", this.getX()-32*width, this.getY());

            if(walls.getOrDefault(identifier, null)!= null){
                return true; 
            }
        }
        else if (direction.equals("right")){
            String identifier1 = String.format("%d,%d", this.getX()+32*width, this.getY());
            if(walls.getOrDefault(identifier1, null)!= null){
                return true; 
            }
        } else if (direction.equals("up")){ //up and down
            String identifier2 = String.format("%d,%d", this.getX(), this.getY()-32*width);
            if(walls.getOrDefault(identifier2, null)!= null){
                return true; 
            }
        }else if (direction.equals("down")){
            String identifier3 = String.format("%d,%d", this.getX(), this.getY()+32*width);
            if(walls.getOrDefault(identifier3, null)!= null){
                return true; 
            }
        }

        return false;
    }



}