package demolition;
/**
*Contains possible game Tiles. These vary from solid, broken, empty or the goal tile drawn in the game.
*/
 public enum tiletypes{
    /**
    *Solid tiles represent game walls. 
    */
    solid,
    /**
    *Broken tiles represent broken game walls. 
    */
    broken,
    /**
    *Empty tiles cover remaining game space and are used for player and enemy spawn points.
    */
    empty,
    /**
    *Goal tiles represent finishing tile in the game. 
    */
    goal;
}
