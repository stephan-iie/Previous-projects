package demolition;
import processing.core.PApplet;
import processing.core.PImage;
import java.util.HashMap;
import java.util.ArrayList;
import processing.core.PFont;
import java.util.Arrays;
import processing.data.JSONObject;
import processing.data.JSONArray;
import java.util.Scanner;

import java.io.File;
import java.io.FileNotFoundException;

/**
*Class manages all levels and state of the game
*/
public class Levels{ 
    private int levelNumber;
    private ArrayList<String> levelPaths;
    private ArrayList<Integer> levelTimers;
    private int levelLives;
    private boolean gameOver=false;
    private PImage clock;
    private PImage livesIcon;
    private int counter =0;
    private boolean gameWin=false;


    private Map map;
    private int[] start;
    private int[] finish;
    private Player player;
    private ArrayList<Enemies> enemies;
    private int timer;

    /**
    *Loads the configuration file and saves these as Arraylists for the levelpaths, and timers. Setsup the first level by initialising the level map, player and enemies.  
    *@param file Configuration file (JSON file holding level paths, timers and lives for the player )
    *@param livesIcon PImage object of the lives icon displayed in the game UI
    *@param clock PImage object of the clock displayed in the game UI
    */
    public Levels(String file, PImage livesIcon, PImage clock){ 
        this.levelPaths=new ArrayList<String>();
        this.levelTimers = new ArrayList<Integer>();
        this.levelsSetup(file);

        this.levelNumber = 0;
        this.clock=clock;
        this.livesIcon= livesIcon;

        this.levelSetup();
    }

    /**
    *Gets the player object
    *@return Player object
    */
    public Player getPlayer(){
        return this.player;
    }
    /**
    *Gets all enemies which are currently still active (Both red and yellow)
    *@return ArrayList of enemies 
    */
    public ArrayList<Enemies> getEnemies(){
        return this.enemies;
    }
    /**
    *Gets all level paths 
    *@return ArrayList of level path stings 
    */
    public ArrayList<String> getLevelPaths(){
        return this.levelPaths;
    }
    /**
    *Gets all the timers for the levels 
    *@return ArrayList of integers containing the level timers for the levelpath in the associated position
    */
    public ArrayList<Integer> getTimers(){
        return this.levelTimers;
    }
    /**
    *Gets lives set for each level 
    *@return Integer indicating lives 
    */
    public int getLives(){
        return this.levelLives;
    }
    /**
    *Gets current level number, i.e. index in list of level paths 
    *@return Integer indicaing current level number 
    */
    public int getLevelNumber(){
        return this.levelNumber;
    }
    /**
    *Indicates if the player won the game
    *@return True if game has been won by player and false otherwise
    */
    public boolean getGameWin(){
        return this.gameWin;
    }
    /**
    *Indicates if the player lost the game
    *@return True if the player has lost the game and false otherwise
    */
    public boolean getGameOver(){
        return this.gameOver;
    }
    /**
    *Gets the coordinates of the goal tile 
    *@return int[] containing the x and y coordinates of the goal tile
    */
    public int[] getFinish(){
        return this.finish;
    }


    private void levelSetup() throws levelSetupIssue{
        // Check it is a valid path of timers and levels

        for (int i = 0; i<this.levelTimers.size();i++){
            if( this.levelTimers.get(i)<= 0){
                throw new levelSetupIssue("ERROR: Negative timers");
            }
        }


        // Setting up the map and all the player starts
        this.enemies =  new ArrayList<Enemies>();
        this.timer  = this.levelTimers.get(this.levelNumber);
        this.map  =  new Map(this.levelPaths.get(this.levelNumber));
        this.map.importMap();

        // Player setup
        this.start  =  map.getPlayerStart();
        this.finish  = map.getFinish();
        this.player  =  new Player(this.start[0], this.start[1], this.levelLives);
        Moving.setMapWalls(this.map.getWalls());


        // gets the start positions 
        ArrayList<int[]> Reds = this.map.getEnemiesRStart();
        ArrayList<int[]> Yellows = this.map.getEnemiesYStart();

        // Initalise the enemies 
        for(int[] starting: Reds){
            RedEnemy r = new RedEnemy(starting[0], starting[1]);
            this.enemies.add(r);
        }

        for(int[] starting: Yellows){
            YellowEnemy y = new YellowEnemy(starting[0], starting[1]);
            this.enemies.add(y);
        }
    }

    

    /**
    *Moves all objects forward by one frame. Also indicates whether the player has finished the level, killed an enemy or has been killed
    */
    public void tick(){
        this.player.tick();

        // If the player is in the winning tile 
        if(this.player.getX() == this.finish[0] && this.player.getY() == this.finish[1]){
            this.finishLevel();
            return;
        }

        for (Enemies enemy: this.enemies){
            if (enemy.enemyKilled() == false){
                enemy.tick(); // move to the new lcoaion first
            }
        }


        // goes through ticks for bomb and returns new explosion locations
        ArrayList<int[]> explosionZone = Bomb.explode();


        // for the places where the bomb has detonated, check whether player or enmemies have been killed 
        for(int[] deathZone: explosionZone){

            // If the player is in the bomb zone, kill the plauer 
            if (this.player.getX()  == deathZone[1] && this.player.getY() ==  deathZone[2]){
                this.playerDeath();

            }

            // If the enemy is in the dead zone  kill the enemy 
            for (Enemies enemy: this.enemies){
                if (enemy.getX() == deathZone[1] && enemy.getY() == deathZone[2]){
                    enemy.killEnemy(); 
                }
            }
        }
        
        // Removes enemies if theyve been killed 
        this.enemies.removeIf(i -> i.enemyKilled() == true);

        // See if the player walked into any enemies, if so kill them
        if (Enemies.enemyMet(this.player.getX(), this.player.getY(), this.enemies) == true){
            this.playerDeath();
        }

    }


   /**
    *Draws the current frame of the game with all player, enemy and bomb positions. Will display the winning or losing sceen if the events have been triggered
    *@param app The app you want to draw the object in 
    */
    public void draw(PApplet app){
        this.counter++;

        // Sets up the timer for the round 
        if (this.counter > 1*App.FPS){
            this.timer--;
            this.counter=0;
        }

        // Checks if the player won the game 
        if (this.gameWin){
            app.fill(0);
            app.textSize(20);
            app.text("YOU WIN", 145,225);
            return;
        }

        if(this.timer <=0){
            this.gameOver=true;
        }

        // Checks if the game is lost 
        if (this.gameOver ){
            app.fill(0);
            app.textSize(20);
            app.text("GAME OVER", 140,225);
            return;

        // every second of the game 
        }else{

            // Outputs lives and seconds left 
            app.fill(0);
            app.textSize(20);
            app.text(String.format("%s", this.player.getLives()), 170,44);
            app.text(String.format("%s",this.timer), 296,44);
            app.image(clock, 260, 16);
            app.image(livesIcon, 132, 16);

            this.map.draw(app);


            // Draw all the bombs and player  and emeies
            Bomb.drawBombs( app);

            this.player.draw(app);
            for (Enemies enemy: this.enemies){

                if (enemy.enemyKilled() == false && enemy!=null ){
                    enemy.draw(app);
                }
            }
            
        }

    }


    // Indicates the game has been finished 
    private void finishLevel(){
        this.levelNumber++;

        // Greater equal to since incremented level first 
        if (this.levelNumber >= this.levelPaths.size()){
            this.gameWin=true;
            return;            
        }

        // Sets up the next level if not the last level 
        this.levelSetup();
        this.tick();
    }

    /**
    *Places a bomb on the players current position on the map 
    */
    public void placeBomb(){
        Bomb newBomb = new Bomb(this.player.getX(), this.player.getY(), this.map);
    }

    // Resets player location and indicates the player has died. Triggers the game over tag if the player has no more lives  
    private void playerDeath(){
        this.player.setLocation(this.start[0], this.start[1]);
        this.player.dead();

        if (this.player.noMoreLives() == true){
            this.gameOver=true;
        }
    }


    /**
    *Sets up the configuration file and saves the level paths, level timers and player lives. This is automatically called during Levels Constructor
    *@param fileName Path of the level file 
    *@exception levelSetupIssue if the file is in the incorrect format or cannot be found
    */
    public void levelsSetup(String fileName) throws levelSetupIssue { 
     //Setup maps 
        File f= new File(fileName);
        String fullConfig = "";
        
        try{
            Scanner scan = new Scanner(f);
        
            while (scan.hasNext()){
                String addLine = scan.next();
                fullConfig +=addLine;
            }            
        } catch (FileNotFoundException e){
            throw new levelSetupIssue("Error: File issue");
        }

        // Parse as file, find the list of levels and find the lives set
        JSONObject file = new JSONObject().parse(fullConfig);
        JSONArray levels =  file.getJSONArray("levels");
        this.levelLives= file.getInt("lives");

        // Looks for the path and the timer of each one and adds to list
        for(int i =0;i<levels.size(); i++){
            JSONObject level = levels.getJSONObject(i);
            this.levelPaths.add(level.getString("path"));
            this.levelTimers.add(level.getInt("time"));
        }

    }

}



