package demolition;

import processing.core.PImage;
import processing.core.PApplet;
import java.util.HashMap;
import java.util.List;

/**
*Abstract class for any people objects 
*/ 
public abstract class Person extends Moving{
    /**
    *Timer indicating seconds passed
    */ 
    protected int timer = 0;
    /**
    *Counter to indicate which animation image we are using 
    */ 
    protected int counter = 0;
    /**
    *Indicates the animation we are using. Depends on the direction the person object is moving 
    */ 
    protected String animationCycle; 

    /**
    *Initialises person object with x and y coordinates 
    *@param x x coordinate
    *@param y y coordinate
    */ 
    public Person(int x, int y){
        super(x,y);
    }


    /**
    *Sets and controls the walking animations of the person object. The images should be in the order in which they should appear to create the animation
    *@param animations PImage[] array storing 4 images which make up the animation of the object. 
    */ 
    protected void walk(PImage[] animations){ //timer is reset once pressed, this is called eveyr tick 
        if (animations == null || animations.length !=4){
            System.err.println("Error: no animation");
            return;
        }

        PImage a1 = animations[0];
        PImage a2 = animations[1];
        PImage a3 = animations[2];
        PImage a4 = animations[3];

        // makes sure we start at the beginning  
        if (this.counter == 0){
            this.setSprite(animations[counter%4]);
            counter++;
        }
        
        // ensures we get it every 0.2 of a secnd -> iterates through 
        if (this.timer>0.2*App.FPS){
            this.setSprite(animations[counter%4]);
            this.counter ++;
            this.timer = 0;
        }
    }

}
