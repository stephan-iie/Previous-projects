package demolition;


import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PFont;

/**
*Manages what is being drawn on the screen. 
*/
public class App extends PApplet {
    /**
    *Frame Width 480 pixels
    */
    public static final int WIDTH = 480;
    /**
    *Frame Height 480 pixels
    */
    public static final int HEIGHT = 480;
    /**
    *Frame per seconds set at 60.
    */
    public static final int FPS = 60;

    /**
    *Font object for game
    */
    public PFont font;
    /**
    *Contains all the levels loaded in the game 
    */
    private Levels  game;
    /**
    *Maps the tiletypes and the PImage object
    */
    public Tiles tilemapper;
    /**
    *Path to json file indicating the levels, timers and lives for the game
    */
    private static String maps = "config.json"; //"src/test/resources/levelsTest.json";//

    /**
    *Initialises size of app window
    */
    public void settings() {
        size(WIDTH, HEIGHT);
    }

    /**
    *Sets the configuration file (Json file containing level maps, timers and lives)
    *@param maps Path to the configuration file
    */
    public static void setConfig(String maps){
        App.maps = maps;
    }

    /**
    *Sets up the game by setting the framerate, creating the font for the game, setting animations of Tiles, Player, Enemy and Bomb classes as well as loading in other game UI icons. The Levels object is initialised. 
    */
    public void setup() {
        frameRate(FPS);

        this.font = createFont("src/main/resources/PressStart2P-Regular.ttf", 10);

        // Gets map rendered 
        Tiles.setTiles(this);

        Player.setAnimations(this);
        RedEnemy.setAnimations(this);
        YellowEnemy.setAnimations(this);
        Bomb.setAnimations(this);
        PImage clock = this.loadImage("src/main/resources/icons/clock.png");
        PImage livesIcon = this.loadImage("src/main/resources/icons/player.png");

        this. game = new Levels( this.maps, livesIcon, clock);
    }

    /**
    *Gets the Levels object of the game
    *@return Returns Levels object which manages the level being drawn
    */
    public Levels getLevel(){
        return this. game;
    }
    /**
    *Sets the keycode for keyReleased
    *@param num Keycode to be used
    */
    public void setKeyCode(int num){
        this.keyCode = num;
    }
    /**
    *Draws one frame of the game. Moves all objects one frame ahead and draws the frame. 
    */
    public void draw() {
        background(255, 165, 0);
        textFont(this.font);
        this. game.tick();
        this. game.draw(this);
    }

    public static void main(String[] args) {
        PApplet.main("demolition.App");
        
    }

    /**
    *Linkes keys pressed to associated player movements
    */
    public void keyReleased() { 
        if (this.keyCode == 37) { // Left: 37
            this. game.getPlayer().pressLeft();
        } else if (this.keyCode == 39) {// Right: 39
            this. game.getPlayer().pressRight();
        }else if (this.keyCode == 38) { // Up: 38
            this. game.getPlayer().pressUp();
        }else if (this.keyCode == 40) { // Down: 40
            this. game.getPlayer().pressDown();
        } else if (this.keyCode == 32){ // Space: 32
            this. game.placeBomb();
        }
    }
}
