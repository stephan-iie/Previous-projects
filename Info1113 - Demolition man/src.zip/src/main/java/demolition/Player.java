package demolition;
import processing.core.PImage;
import processing.core.PApplet;

import java.util.HashMap;

/**
*Manages player location, state and movements  
*/
public class Player extends Person{
    private static HashMap<String, PImage[]> animations = new HashMap<String, PImage[]>();

 
    private int Lives;

    /**
    *Initialises player object 
    *@param x x coordinate
    *@param y y coordinate
    *@param lives Number of maximum lives the player can have in the level
    */
    public Player(int x, int y, int lives){
        super(x,y);
        this.moveLR = 0;
        this.moveUD = 0;
        this.animationCycle = "down";
        this.Lives = lives;
        
    }

    /**
    *Sets the location of the player to a new location 
    *@param x x coordinate
    *@param y y coordinate
    */
    public void setLocation(int x, int y){
        this.x = x;
        this.y = y;
    }

    /**
    *Sets the animations of the player object. Call before moving the object. 
    *@param app The app which you want to draw in 
    */
    public static void setAnimations(PApplet app){
        // Load player animations during setup
        PImage up1 = app.loadImage("src/main/resources/player/player_up1.png");
        PImage up2 = app.loadImage( "src/main/resources/player/player_up2.png");
        PImage up3 = app.loadImage("src/main/resources/player/player_up3.png");
        PImage up4 = app.loadImage("src/main/resources/player/player_up4.png");

        PImage left1 = app.loadImage("src/main/resources/player/player_left1.png");
        PImage left2 = app.loadImage("src/main/resources/player/player_left2.png");
        PImage left3 = app.loadImage("src/main/resources/player/player_left3.png");
        PImage left4 = app.loadImage("src/main/resources/player/player_left4.png");

        PImage right1 = app.loadImage("src/main/resources/player/player_right1.png");
        PImage right2 = app.loadImage("src/main/resources/player/player_right2.png");
        PImage right3 = app.loadImage("src/main/resources/player/player_right3.png");
        PImage right4 = app.loadImage("src/main/resources/player/player_right4.png");

        PImage down1 = app.loadImage("src/main/resources/player/player1.png");
        PImage down2 = app.loadImage("src/main/resources/player/player2.png");
        PImage down3 = app.loadImage("src/main/resources/player/player3.png");
        PImage down4 = app.loadImage("src/main/resources/player/player4.png");

        PImage[] walkUp = new PImage[] {up1, up2, up3, up4};
        Player.animations.put("up", walkUp);
        PImage[] walkLeft = new PImage[] {left1, left2, left3, left4};
        Player.animations.put("left", walkLeft);
        PImage[] walkRight = new PImage[] {right1, right2, right3, right4};
        Player.animations.put("right", walkRight);
        PImage[] walkDown = new PImage[] {down1, down2, down3, down4};
        Player.animations.put("down", walkDown);

    }


    /**
    *Moves the object forward in time by one frame by changing the animation and moving the player if there is no wall ahead
    */
    public void tick(){ 
        this.timer++;
        if (Player.animations.size() != 0){
            this.walk(animations.get(this.animationCycle));
        }else{
            System.err.println("ERROR: no walking animation loaded. Please call setAnimations() first");
        }
        if(this.moveLR == 1){
            
            this.x+= 32;
            this.moveLR=0;
        }else if(this.moveLR ==-1){
           
            this.x-= 32;
            this.moveLR=0;
        }else if(this.moveUD ==1){
            
            this.y-= 32;
            this.moveUD=0;
        }else if(this.moveUD ==-1){
            this.y+= 32;
            this.moveUD=0;
        }
    }


    /**
    *Kills the player by decreasing their lives and resetting the animation cycle to "down"
    */
    public void dead(){
        if (this.Lives == 0){
            return;
        }
        this.Lives --;
        this.animationCycle = "down";
    }

    /**
    *Returns current animation cycle 
    *@return Returns the direction of the animation "up", "down", "left", "right"
    */
    public String getAnimationCycle(){
        return this.animationCycle;
    }

    /**
    *Indicates if the player has no more lives 
    *@return Returns true if no more lives and false if player still has lives 
    */
    public boolean noMoreLives(){
        if(this.Lives == 0){
            return true;
        }
        return false;
    }

    /**
    *Returns players current number of lives left 
    *@return Returns integer of lives left 
    */
    public int getLives(){
        return this.Lives;
    }
    


    private void resetCycle(){
        this.timer = 0;
        this.counter = 0;
    }

    /**
    *Moves the player left if there is no wall 
    */
    public void pressLeft(){
        if (this.checkForWalls( "left",1) == false){
            this.animationCycle ="left";
            this.moveLR = -1;
            this.resetCycle();
        }

    }

    /**
    *Moves the player left if there is no wall 
    */
    public void pressRight(){

        if (this.checkForWalls( "right", 1) == false){
            this.animationCycle = "right";
            this.moveLR = 1;
            this.resetCycle();
        }
    }

    /**
    *Moves the player up if there is no wall 
    */
    public void pressUp(){
        if (this.checkForWalls("up",1 ) == false){
            this.animationCycle = "up";
            this.moveUD = 1;
            this.resetCycle();
        }    
    }


    /**
    *Moves the player down if there is no wall 
    */
    public void pressDown(){
        if (this.checkForWalls( "down",1) == false){
            this.animationCycle = "down";
            this.moveUD = -1;
            this.resetCycle();
        }    
    }
} 