package demolition;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SampleTest {
    
    @Test
    public void simpleTest() {
        assertEquals(480, App.HEIGHT);
    }
}
