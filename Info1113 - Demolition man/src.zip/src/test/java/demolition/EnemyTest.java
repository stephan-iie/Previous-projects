
package demolition;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.HashMap;
import java.util.ArrayList;


public class EnemyTest {

    
    // Test returns true if meets enemy 
    @Test
    public void enemyMet() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>());
        p.pressDown();
        p.tick();
        assertEquals(32, p.getX()); // this is the coumns  
        assertEquals(112, p.getY());// this is the rows
        assertEquals("down", p.getAnimationCycle());
        //assert equals for the moveLR 

        ArrayList<Enemies> enemyLocations = new ArrayList<Enemies>();
        RedEnemy red = new RedEnemy(32,112);
        enemyLocations.add(red);
        assertTrue(Enemies.enemyMet(p.getX(), p.getY(), enemyLocations ));

    }


    // Test enemy behind the player 
    @Test
    public void enemyBehind() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>());

        p.pressDown();
        p.tick();
        assertEquals(32, p.getX()); // this is the coumns  
        assertEquals(112, p.getY());// this is the rows
        assertEquals("down", p.getAnimationCycle());

        ArrayList<Enemies> enemyLocations = new ArrayList<Enemies>();
        enemyLocations.add(new RedEnemy(32,80));
        assertFalse(Enemies.enemyMet(p.getX(), p.getY(), enemyLocations ));

    }

    // Test returns noEnemy
    @Test
    public void noEnemy() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>());

        p.pressDown();
        p.tick();
        assertEquals(32, p.getX()); // this is the coumns  
        assertEquals(112, p.getY());// this is the rows
        assertEquals("down", p.getAnimationCycle());

        ArrayList<Enemies> enemyLocations = new ArrayList<Enemies>();
        assertFalse(Enemies.enemyMet(p.getX(), p.getY(), enemyLocations ));

    }

    // Test returns no enemies
    @Test
    public void nullEnemyArray() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>());

        p.pressDown();
        p.tick();
        assertEquals(32, p.getX()); // this is the coumns  
        assertEquals(112, p.getY());// this is the rows
        assertEquals("down", p.getAnimationCycle());

        assertFalse(Enemies.enemyMet(p.getX(), p.getY(), null ));

    }

}