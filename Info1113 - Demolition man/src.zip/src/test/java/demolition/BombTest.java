package demolition;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;

public class BombTest {
    

    @Test
    public void constructorTest() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Bomb bomb = new Bomb(32,80,map);
        assertEquals(32, bomb.getX());
        assertEquals(80, bomb.getY());
        ArrayList<Bomb> bombs = Bomb.getBombs();
        assertEquals(1, bombs.size());
        assertFalse(bomb.exploded());

        // to make sure it doesnt mess up with undetonated bombs
        Moving.setMapWalls(map.getWalls());
        for(int i=0; i<150; i++){
            bomb.tick();
        }
        Bomb.removeBomb();

    }



    // Test exloded + detonate + detonate helper (private methods )=================================================================
    @Test
    public void detonateTimer() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(32,80,map);
        for(int i=0; i<149; i++){
            bomb.tick();
        }
        assertFalse(bomb.exploded());
        bomb.tick();
        assertTrue(bomb.exploded());

    }


    // Test removeBomb if exploded (it is inherently buiilt into the tick )=================================================================
    @Test
    public void removeBomb() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(32,80,map);

        for(int i=0; i<150; i++){
            bomb.tick();
        }
        assertTrue(bomb.exploded());
        ArrayList<Bomb> bombs = Bomb.getBombs();
        assertEquals(1, bombs.size());
        Bomb.removeBomb();
        assertEquals(0, bombs.size());
    }


    // Test remove bomb if not exploded 
    @Test
    public void removeBomb2() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(32,80,map);
        Bomb bomb2 = new Bomb(32,80,map);

        for(int i=0; i<150; i++){
            bomb.tick();
        }

        for(int i=0; i<149; i++){
            bomb2.tick();
        }
        
        ArrayList<Bomb> bombs = Bomb.getBombs();
        assertEquals(2, bombs.size());
        Bomb.removeBomb();
        assertEquals(1, bombs.size());
        bomb2.tick();
        Bomb.removeBomb();
        assertEquals(0, bombs.size());

    }

    // Detonate within limts=================================================================

   @Test
    public void detonateNearSolid() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(160,80,map);
        HashMap<String, int[]> walls = map.getWalls();
        int current = walls.size();
        for(int i=0; i<150; i++){
            bomb.tick();
        }
        Bomb.removeBomb();

        assertEquals(current,walls.size());
        assertTrue(walls.containsKey("160,48") );
        assertTrue(walls.containsKey("160,112"));

    }

    // Detonate and break walls 
   @Test
    public void detonateNearBroken() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(32,272,map);
        HashMap<String, int[]> walls = map.getWalls();
        int current = walls.size();
        for(int i=0; i<150; i++){
            bomb.tick();
        }
        Bomb.removeBomb();

        assertEquals(current-2,walls.size());
        assertFalse(walls.containsKey("32,240") );
        assertFalse(walls.containsKey("32,304"));

    }


    // detonate anywehre 
    @Test
    public void detonateInOpen() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(256,144,map);
        HashMap<String, int[]> walls = map.getWalls();
        int current = walls.size();
        for(int i=0; i<150; i++){
            bomb.tick();
        }
        Bomb.removeBomb();

        assertEquals(current,walls.size());
    }


    // Testing explosion zone function (list of explosion locations availbel )=================================================================
    @Test
    public void solidNoExplosion() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(160,80,map);
        HashMap<String, int[]> walls = map.getWalls();
        int current = walls.size();
        for(int i=0; i<120; i++){
            bomb.tick();
        }
        ArrayList<int[]> explosionZone = bomb.getExplosionZone();

        assertEquals(0,explosionZone.get(0)[0]);
        assertEquals(160,explosionZone.get(0)[1]);
        assertEquals(80,explosionZone.get(0)[2]);

        assertEquals(1,explosionZone.get(1)[0]);
        assertEquals(128,explosionZone.get(1)[1]);
        assertEquals(80,explosionZone.get(1)[2]);

        assertEquals(3,explosionZone.get(2)[0]);
        assertEquals(96,explosionZone.get(2)[1]);
        assertEquals(80,explosionZone.get(2)[2]);

        
        assertEquals(1,explosionZone.get(3)[0]);
        assertEquals(192,explosionZone.get(3)[1]);
        assertEquals(80,explosionZone.get(3)[2]);

        assertEquals(4,explosionZone.get(4)[0]);
        assertEquals(224,explosionZone.get(4)[1]);
        assertEquals(80,explosionZone.get(4)[2]);

        for(int i=0; i<30; i++){
            bomb.tick();
        }
        Bomb.removeBomb();
    }

    // Testing explosion near walls and checking it overlaps 
   @Test
    public void brokenExplosion() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(32,272,map);
        HashMap<String, int[]> walls = map.getWalls();
        int current = walls.size();
        for(int i=0; i<120; i++){
            bomb.tick();
        }
        ArrayList<int[]> explosionZone = bomb.getExplosionZone();
        assertEquals(0,explosionZone.get(0)[0]);
        assertEquals(32,explosionZone.get(0)[1]);
        assertEquals(272,explosionZone.get(0)[2]);

       assertEquals(2,explosionZone.get(1)[0]);
        assertEquals(32,explosionZone.get(1)[1]);
        assertEquals(240,explosionZone.get(1)[2]);

        assertEquals(2,explosionZone.get(2)[0]);
        assertEquals(32,explosionZone.get(2)[1]);
        assertEquals(304,explosionZone.get(2)[2]);

        assertEquals(1,explosionZone.get(3)[0]);
        assertEquals(64,explosionZone.get(3)[1]);
        assertEquals(272,explosionZone.get(3)[2]);
        assertEquals(4,explosionZone.get(4)[0]);
        assertEquals(96,explosionZone.get(4)[1]);
        assertEquals(272,explosionZone.get(4)[2]);
        for(int i=0; i<30; i++){
            bomb.tick();
        }
        Bomb.removeBomb();

    }

    // Checking exlosion zone when not blocked by obstacles
    @Test
    public void fullCrossExplosion() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(256,176,map);
        HashMap<String, int[]> walls = map.getWalls();
        int current = walls.size();
        for(int i=0; i<120; i++){
            bomb.tick();
        }
        
        ArrayList<int[]> explosionZone = bomb.getExplosionZone();
        assertEquals(0,explosionZone.get(0)[0]);
        assertEquals(256,explosionZone.get(0)[1]);
        assertEquals(176,explosionZone.get(0)[2]);


        assertEquals(2,explosionZone.get(1)[0]);
        assertEquals(256,explosionZone.get(1)[1]);
        assertEquals(144,explosionZone.get(1)[2]);

        assertEquals(5,explosionZone.get(2)[0]);
        assertEquals(256,explosionZone.get(2)[1]);
        assertEquals(112,explosionZone.get(2)[2]);

        assertEquals(2,explosionZone.get(3)[0]);
        assertEquals(256,explosionZone.get(3)[1]);
        assertEquals(208,explosionZone.get(3)[2]);

        assertEquals(6,explosionZone.get(4)[0]);
        assertEquals(256,explosionZone.get(4)[1]);
        assertEquals(240,explosionZone.get(4)[2]);

        assertEquals(1,explosionZone.get(5)[0]);
        assertEquals(224,explosionZone.get(5)[1]);
        assertEquals(176,explosionZone.get(5)[2]);

        assertEquals(3,explosionZone.get(6)[0]);
        assertEquals(192,explosionZone.get(6)[1]);
        assertEquals(176,explosionZone.get(6)[2]);

        assertEquals(1,explosionZone.get(7)[0]);
        assertEquals(288,explosionZone.get(7)[1]);
        assertEquals(176,explosionZone.get(7)[2]);

        assertEquals(4,explosionZone.get(8)[0]);
        assertEquals(320,explosionZone.get(8)[1]);
        assertEquals(176,explosionZone.get(8)[2]);


        for(int i=0; i<30; i++){
            bomb.tick();
        }
        Bomb.removeBomb();

    }

    // Testing explode with nothing 
   @Test
    public void noExplode() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());

        ArrayList<int[]> explode = Bomb.explode();
        assertTrue(explode.size() ==0 || explode ==null);

    }


    // Testing explode with two bombs 
    @Test
    public void explodeStaticList() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(256,176,map);
        Bomb bomb2 = new Bomb(32,272,map);
        HashMap<String, int[]> walls = map.getWalls();
        int current = walls.size();
        for(int i=0; i<120; i++){
            bomb.tick();
            bomb2.tick();
        }
        
        ArrayList<int[]> explode = Bomb.explode();
        assertEquals(0,explode.get(0)[0]);
        assertEquals(256,explode.get(0)[1]);
        assertEquals(176,explode.get(0)[2]);


        assertEquals(2,explode.get(1)[0]);
        assertEquals(256,explode.get(1)[1]);
        assertEquals(144,explode.get(1)[2]);

        assertEquals(5,explode.get(2)[0]);
        assertEquals(256,explode.get(2)[1]);
        assertEquals(112,explode.get(2)[2]);

        assertEquals(2,explode.get(3)[0]);
        assertEquals(256,explode.get(3)[1]);
        assertEquals(208,explode.get(3)[2]);

        assertEquals(6,explode.get(4)[0]);
        assertEquals(256,explode.get(4)[1]);
        assertEquals(240,explode.get(4)[2]);

        assertEquals(1,explode.get(5)[0]);
        assertEquals(224,explode.get(5)[1]);
        assertEquals(176,explode.get(5)[2]);

        assertEquals(3,explode.get(6)[0]);
        assertEquals(192,explode.get(6)[1]);
        assertEquals(176,explode.get(6)[2]);

        assertEquals(1,explode.get(7)[0]);
        assertEquals(288,explode.get(7)[1]);
        assertEquals(176,explode.get(7)[2]);

        assertEquals(4,explode.get(8)[0]);
        assertEquals(320,explode.get(8)[1]);
        assertEquals(176,explode.get(8)[2]);

        assertEquals(0,explode.get(9)[0]);
        assertEquals(32,explode.get(9)[1]);
        assertEquals(272,explode.get(9)[2]);

       assertEquals(2,explode.get(10)[0]);
        assertEquals(32,explode.get(10)[1]);
        assertEquals(240,explode.get(10)[2]);

        assertEquals(2,explode.get(11)[0]);
        assertEquals(32,explode.get(11)[1]);
        assertEquals(304,explode.get(11)[2]);

        assertEquals(1,explode.get(12)[0]);
        assertEquals(64,explode.get(12)[1]);
        assertEquals(272,explode.get(12)[2]);
        assertEquals(4,explode.get(13)[0]);
        assertEquals(96,explode.get(13)[1]);
        assertEquals(272,explode.get(13)[2]);

        for(int i=0; i<30; i++){
            bomb.tick();
            bomb2.tick();

        }
        Bomb.removeBomb();

    }


    // Testing explode with one bomb in detonate, other not 
    @Test
    public void halfDetonated() {
        Map map = new Map("src/test/resources/bombTest.txt");
        map.importMap();
        Moving.setMapWalls(map.getWalls());
        Bomb bomb = new Bomb(256,176,map);
        Bomb bomb2 = new Bomb(32,272,map);
        HashMap<String, int[]> walls = map.getWalls();
        int current = walls.size();
        for(int i=0; i<120; i++){
            bomb.tick();
        }
        
        ArrayList<int[]> explode = Bomb.explode();
        assertEquals(0,explode.get(0)[0]);
        assertEquals(256,explode.get(0)[1]);
        assertEquals(176,explode.get(0)[2]);


        assertEquals(2,explode.get(1)[0]);
        assertEquals(256,explode.get(1)[1]);
        assertEquals(144,explode.get(1)[2]);

        assertEquals(5,explode.get(2)[0]);
        assertEquals(256,explode.get(2)[1]);
        assertEquals(112,explode.get(2)[2]);

        assertEquals(2,explode.get(3)[0]);
        assertEquals(256,explode.get(3)[1]);
        assertEquals(208,explode.get(3)[2]);

        assertEquals(6,explode.get(4)[0]);
        assertEquals(256,explode.get(4)[1]);
        assertEquals(240,explode.get(4)[2]);

        assertEquals(1,explode.get(5)[0]);
        assertEquals(224,explode.get(5)[1]);
        assertEquals(176,explode.get(5)[2]);

        assertEquals(3,explode.get(6)[0]);
        assertEquals(192,explode.get(6)[1]);
        assertEquals(176,explode.get(6)[2]);

        assertEquals(1,explode.get(7)[0]);
        assertEquals(288,explode.get(7)[1]);
        assertEquals(176,explode.get(7)[2]);

        assertEquals(4,explode.get(8)[0]);
        assertEquals(320,explode.get(8)[1]);
        assertEquals(176,explode.get(8)[2]);

        assertTrue(explode.size() ==9);

        for(int i=0; i<160; i++){
            bomb.tick();
            bomb2.tick();

        }
        Bomb.removeBomb();

    }




}
