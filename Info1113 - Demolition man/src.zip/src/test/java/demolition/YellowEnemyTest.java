package demolition;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.HashMap;

public class YellowEnemyTest {
    
    @Test
    public void constructorTest() {
        YellowEnemy yellow = new YellowEnemy(32, 80);
        assertEquals(32, yellow.getX());
        assertEquals(80, yellow.getY());
        assertFalse(yellow.enemyKilled());
    }




    // Checking tick=================================================================


    // Checking enemy killed
    @Test
    public void killEnemyTest() {
        YellowEnemy yellow = new YellowEnemy(32, 80);
        assertFalse(yellow.enemyKilled());
        yellow.killEnemy();
        assertTrue(yellow.enemyKilled());

    }


    // Continue going striaght if no wall 
    @Test
    public void continueStraight() {
        YellowEnemy yellow = new YellowEnemy(32, 80);
        yellow.setMapWalls(new HashMap<String, int[]>());
        String currentDirection = yellow.getAnimationCycle();
        yellow.tick();
        assertEquals(currentDirection, yellow.getAnimationCycle());
    }

    // Go clockwise 
    // Check can only go left
    @Test
    public void goLeft() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 
        yellow.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("64,80", new int[]{64,80});}});
        yellow.tick();
        assertEquals("left", yellow.getAnimationCycle());
        for(int i=0; i<60; i++){ // it takes 60 ticks for it to move 
            yellow.tick();
        }
        assertEquals(0, yellow.getX()); // this is the coumns  
        assertEquals(80, yellow.getY());// this is the rows
    }

    // Check can only go right 
    @Test
    public void goRight() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 
        yellow.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("0,80", new int[]{0,80});}});
        yellow.tick();
        for(int i=0; i<60; i++){ // it takes 60 ticks for it to move 
            yellow.tick();
        }
        assertEquals("right", yellow.getAnimationCycle());

        assertEquals(64, yellow.getX()); // this is the coumns  
        assertEquals(80, yellow.getY());// this is the rows
    }

    // Check can only go up
    @Test
    public void goUp() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 
        yellow.setMapWalls(new HashMap<String, int[]>(){{put("64,80", new int[]{64,80});
                                                    put("32,112", new int[]{32,112});
                                                    put("0,80", new int[]{64,80});}});
        
        yellow.tick();
        for(int i=0; i<60; i++){ // it takes 60 ticks for it to move 
            yellow.tick();
        }
        assertEquals("up", yellow.getAnimationCycle());

        assertEquals(32, yellow.getX()); // this is the coumns  
        assertEquals(48, yellow.getY());// this is the rows
    }
    // Check can only go down 
   @Test
    public void goDown() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 
        yellow.setMapWalls(new HashMap<String, int[]>(){{put("64,80", new int[]{64,80});
                                                    put("32,48", new int[]{32,48});
                                                    put("0,80", new int[]{64,80});}});
        yellow.tick();
        assertEquals("down", yellow.getAnimationCycle());
        for(int i=0; i<60; i++){ // it takes 60 ticks for it to move 
            yellow.tick();
        }
        assertEquals(32, yellow.getX()); // this is the coumns  
        assertEquals(112, yellow.getY());// this is the rows
    }


    // Go right and then go clockwise down 
   @Test
    public void rightDown() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 
        yellow.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("96,80", new int[]{96,80});
                                                    put("0,80", new int[]{0,80});}});
        yellow.tick();
        for(int i=0; i<60; i++){ // it takes 60 ticks for it to move 
            yellow.tick();
        }
        assertEquals("right", yellow.getAnimationCycle());
        assertEquals(64, yellow.getX()); // this is the coumns  
        assertEquals(80, yellow.getY());// this is the rows
        yellow.tick();
        assertTrue(yellow.getAnimationCycle()=="down"  );
 
    }




    // Dont go Right
    @Test
    public void dontGoRight() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 
        yellow.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("64,80", new int[]{64,80});}});

        for(int i=0; i<59; i++){ // it takes 60 ticks for it to move 
            yellow.tick();
        }
        yellow.setAnimationCycle("up");
        yellow.tick();

        assertEquals("right", yellow.getAnimationCycle());
        assertEquals(32, yellow.getX()); // this is the coumns  
        assertEquals(80, yellow.getY());// this is the rows

    }

   // Dont go down 
    @Test
    public void dontGoDown() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 
        yellow.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("64,80", new int[]{64,80});}});

        for(int i=0; i<59; i++){ // it takes 60 ticks for it to move 
            yellow.tick();
        }
        yellow.setAnimationCycle("right");
        yellow.tick();

        assertEquals("down", yellow.getAnimationCycle());
        assertEquals(32, yellow.getX()); // this is the coumns  
        assertEquals(80, yellow.getY());// this is the rows

 
    }

   // Dont go up
    @Test
    public void dontGoUp() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 
        yellow.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("0,80", new int[]{0,80});}});

        for(int i=0; i<59; i++){ // it takes 60 ticks for it to move 
            yellow.tick();
        }
        yellow.setAnimationCycle("left");
        yellow.tick();

        assertEquals("up", yellow.getAnimationCycle());
        assertEquals(32, yellow.getX()); // this is the coumns  
        assertEquals(80, yellow.getY());// this is the rows

 
    }

   // Dont go left
    @Test
    public void dontGoLeft() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 
        yellow.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("0,80", new int[]{0,80});}});

        for(int i=0; i<59; i++){ // it takes 60 ticks for it to move 
            yellow.tick();
        }
        yellow.setAnimationCycle("down");
        yellow.tick();

        assertEquals("left", yellow.getAnimationCycle());
        assertEquals(32, yellow.getX()); // this is the coumns  
        assertEquals(80, yellow.getY());// this is the rows

 
    }

    // Set animationCycle invalid
    @Test
    public void invalidAnimationCycle() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 

        yellow.setAnimationCycle("random");

        assertEquals("down", yellow.getAnimationCycle());

 
    }

    // Check trapped inside one block, should just stay in the same location, animation cycle will change

    @Test
    public void enemyStuck() {
        YellowEnemy yellow = new YellowEnemy(32, 80); // direction always starts down 
        yellow.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("64,80", new int[]{64,112});
                                                    put("0,80", new int[]{0,80});}});
        yellow.tick();
        assertEquals("left", yellow.getAnimationCycle());
        yellow.tick();
        assertEquals("up", yellow.getAnimationCycle());
        yellow.tick();
        assertEquals("right", yellow.getAnimationCycle());
        yellow.tick();
        assertEquals("down", yellow.getAnimationCycle());

        for(int i=0; i<240; i++){ // it takes 60 ticks for it to move 
            yellow.tick();
        }
        assertEquals(32, yellow.getX()); // this is the coumns  
        assertEquals(80, yellow.getY());// this is the rows

        assertEquals("down", yellow.getAnimationCycle());


    }


}


