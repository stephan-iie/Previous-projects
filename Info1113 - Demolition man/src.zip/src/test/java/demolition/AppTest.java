package demolition;

import processing.core.PApplet;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class AppTest {

    // Trying keypressed and moving players right 
    @Test 
    public void TestingKeyRight() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

        // Call draw to update the program.
        app.draw();

        // Call keyPressed() or similar
        Player player = app.getLevel().getPlayer(); 
        assertEquals(32, player.getX()); // this is the coumns  
        assertEquals(80, player.getY());// this is the rows        
        
        app.setKeyCode(39);
        app.keyReleased();

        // Call draw again to move onto the next frame
        app.draw();

        // Verify the new state of the program with assertions
        assertEquals(64, player.getX()); // this is the coumns  
        assertEquals(80, player.getY());// this is the rows

    }

    //Testing key down 
    @Test 
    public void TestingKeyDown() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

        // Call draw to update the program.
        app.draw();

        // Call keyPressed() or similar
        Player player = app.getLevel().getPlayer(); 
        assertEquals(32, player.getX()); // this is the coumns  
        assertEquals(80, player.getY());// this is the rows        
        
        app.setKeyCode(40);
        app.keyReleased();

        // Call draw again to move onto the next frame
        app.draw();

        // Verify the new state of the program with assertions
        assertEquals(32, player.getX()); // this is the coumns  
        assertEquals(112, player.getY());// this is the rows

    }

    //Testing key left 

    @Test 
    public void TestingKeyLeft() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

        // Call draw to update the program.
        app.draw();

        // Call keyPressed() or similar
        Player player = app.getLevel().getPlayer(); 
        assertEquals(32, player.getX()); // this is the coumns  
        assertEquals(80, player.getY());// this is the rows        
        
        app.setKeyCode(39);
        app.keyReleased();

        // Call draw again to move onto the next frame
        app.draw();

        // Verify the new state of the program with assertions
        assertEquals(64, player.getX()); // this is the coumns  
        assertEquals(80, player.getY());// this is the rows

        app.setKeyCode(37);
        app.keyReleased();

        // Call draw again to move onto the next frame
        app.draw();

        // Verify the new state of the program with assertions
        assertEquals(32, player.getX()); // this is the coumns  
        assertEquals(80, player.getY());// this is the rows


    }

    //Testing key up 

    @Test 
    public void TestingKeyUp() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

        // Call draw to update the program.
        app.draw();

        // Call keyPressed() or similar
        Player player = app.getLevel().getPlayer(); 
        assertEquals(32, player.getX()); // this is the coumns  
        assertEquals(80, player.getY());// this is the rows        
        
        app.setKeyCode(40);
        app.keyReleased();

        // Call draw again to move onto the next frame
        app.draw();

        // Verify the new state of the program with assertions
        assertEquals(32, player.getX()); // this is the coumns  
        assertEquals(112, player.getY());// this is the rows

        app.setKeyCode(38);
        app.keyReleased();

        // Call draw again to move onto the next frame
        app.draw();

        // Verify the new state of the program with assertions
        assertEquals(32, player.getX()); // this is the coumns  
        assertEquals(80, player.getY());// this is the rows

    }


    // Test drawing Bomb and all bombs by placing  and getting them all the explode 
    @Test 
    public void TestingBombPlaced() {
        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

        // Call draw to update the program.
        app.draw();

        // Call keyPressed() or similar
        Player player = app.getLevel().getPlayer(); 

        // Move the player all the way to the right  and place a Bomb and go all the way back
        for(int i=0; i<5;i++){
            app.setKeyCode(39);
            app.keyReleased();
            app.draw();
        }
        ArrayList<Bomb> bombs = Bomb.getBombs();
        assertEquals(0, bombs.size());

        assertEquals(160, player.getX()); // this is the coumns  
        assertEquals(80, player.getY());// this is the rows

        app.setKeyCode(32);
        app.keyReleased();
        app.draw();

        // Verify bomb has been placed

        assertEquals(1, bombs.size());
        assertFalse(bombs.get(0).exploded());

        for(int i=0; i<5;i++){
            app.setKeyCode(37);
            app.keyReleased();
            app.draw();
        }


        for(int i=0; i<145; i++){
            app.draw();            
        }
        // Checks the old arraylist of bombs has exploded 

        assertEquals(0, Bomb.getBombs().size());


    }




    // game loss: timer runs out: not placed in levels since needs draw
    @Test 
    public void idleLoss() {
        // Set to config file with 5 second timer 
        App.setConfig("src/test/resources/idleLoss.json");

        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

        // Call draw to update the program.
        app.draw();

        // Call keyPressed() or similar
        for(int i=0; i<=6*60; i++){ // Timer starts counting at 5, hence timer is 6 seocnds
            app.draw();            
        }
        // Checks the old arraylist of bombs has exploded 

        assertTrue(app.getLevel().getGameOver());


        // Reset to config so other tests dont get messed up
        App.setConfig("config.json");


    }


    // Player won from teleporting to win 
    @Test
    public void teleportedWin2(){
       // Set to config file with 5 second timer 
        App.setConfig("src/test/resources/levelsTestOne.json");

        // Create an instance of your application
        App app = new App();

        // Set the program to not loop automatically
        app.noLoop();

        // Set the path of the config file to use
        // app.setConfig("src/test/resources/config.json");

        // Tell PApplet to create the worker threads for the program
        PApplet.runSketch(new String[] {"App"}, app);

        // Call App.setup() to load in sprites
        app.setup();

        // Set a 1 second delay to ensure all resources are loaded
        app.delay(1000);

        // Call draw to update the program.
        app.draw();

        // Call keyPressed() or similar
        Player player = app.getLevel().getPlayer();

        player.setLocation(416,400);
        app.draw();
        assertTrue(app.getLevel().getGameWin());


        // Reset to config so other tests dont get messed up
        App.setConfig("config.json");



    }    


}