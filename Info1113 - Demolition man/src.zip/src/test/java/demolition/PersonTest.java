package demolition;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import processing.core.PImage;


public class PersonTest {
    
    // Test walk with NO animations list 
    @Test
    public void walkTest() {
        Person person = new Player(32, 80, 3);

        person.walk(null);


    }

}