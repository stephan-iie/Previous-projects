package demolition;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.HashMap;

public class MapTest {
    
    @Test
    public void constructorTest() {
        Map map = new Map("src/test/resources/mapTest1.txt");
        tiletypes[][] initial = map.getMapArray();

        // Check we initalise with nothing in the map 
        for(int i=0; i<13; i++){
            for (int j =0; j<15 ; j++){
                assertEquals(null, initial[i][j]);
            }
        }
        
    }

    // Test import map =================================================================
    // Too many rows 
    @Test
    public void tooManyRows() {
        Map map = new Map("src/test/resources/tooManyRows.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - Too many rows";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }
    // Not enough rows 
    @Test
    public void notEnoughRows() {
        Map map = new Map("src/test/resources/notEnoughRows.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - Not enough rows";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Too many columns 
    @Test
    public void tooManyColumns() {
        Map map = new Map("src/test/resources/tooManyColumns.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - Too many columns";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }
    // Not enough columns 
    @Test
    public void notEnoughColumns() {
        Map map = new Map("src/test/resources/notEnoughColumns.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - Not enough columns";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }


    // No Player goal
    @Test
    public void noGoal() {
        Map map = new Map("src/test/resources/noGoal.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - No goal";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Player goal not in wall boundary
    @Test
    public void goalOutside() {
        Map map = new Map("src/test/resources/goalOutside.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - Goal location not in walls";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Player goal in row boundary not in column boundary 
    @Test
    public void goalOutside2() {
        Map map = new Map("src/test/resources/goalOutside2.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - Goal location not in walls";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // No Player start
    @Test
    public void noStart() {
        Map map = new Map("src/test/resources/noPlayer.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - No starting location for player";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Player start not in walls 
    @Test
    public void startOutside() {
        Map map = new Map("src/test/resources/playerOutside.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - Starting location not in walls";
        String actualMessage = exception.getMessage();
        System.out.println(actualMessage);

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Player start in row boundary, not in column boundary 
    @Test
    public void startOutside2() {
        Map map = new Map("src/test/resources/playerOutside2.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - Starting location not in walls";
        String actualMessage = exception.getMessage();
        System.out.println(actualMessage);

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // No solid walls
    @Test
    public void noWalls() {
        Map map = new Map("src/test/resources/noWalls.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: INCORRECT MAP FORMAT - No solid walls";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }




    // File doesnt exist 
    @Test
    public void noFile() {
        Map map = new Map("src/test/resources/nonExistent.txt");
        Exception exception = assertThrows(RuntimeException.class, () -> {map.importMap(); });

        String expectedMessage = "ERROR: File issue";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Right array retuned 
    @Test
    public void correctArray() {
        Map map = new Map("src/test/resources/mapTest1.txt");
        map.importMap();
        tiletypes[][] initial = map.getMapArray();
        for( int i=0; i<15;i++){
            assertEquals(tiletypes.solid,initial[0][i] );
        }
        assertEquals(tiletypes.solid,initial[1][0] );
        assertEquals(tiletypes.empty,initial[1][1] );
        assertEquals(tiletypes.empty,initial[1][2] );
        assertEquals(tiletypes.empty,initial[1][3] );
        assertEquals(tiletypes.empty,initial[1][4] );
        assertEquals(tiletypes.empty,initial[1][5] );
        assertEquals(tiletypes.broken,initial[1][6]);
        assertEquals(tiletypes.empty,initial[1][7] );
        assertEquals(tiletypes.empty,initial[1][8] );
        assertEquals(tiletypes.empty,initial[1][9] );
        assertEquals(tiletypes.empty,initial[1][10] );
        assertEquals(tiletypes.empty,initial[1][11] );
        assertEquals(tiletypes.empty,initial[1][12] );
        assertEquals(tiletypes.solid,initial[1][14] );
        assertEquals(tiletypes.goal,initial[1][13] );
        for( int i=0; i<15;i++){
            assertEquals(tiletypes.solid,initial[2][i] );
        }
    }


    // Testing getwalls method=================================================================

    @Test
    public void getwalls() {
        Map map = new Map("src/test/resources/mapTest1.txt");
        map.importMap();
        HashMap<String, int[]> walls = map.getWalls();
        //x is the col aka 48+32*x
        //y is the row aka 32*y
        assertEquals(33,walls.size());
        assertTrue(walls.containsKey("192,48") );
        assertTrue(walls.containsKey("0,48"));

        assertTrue(walls.containsKey("448,48") );

    }

    // Testing remove wall =================================================================

    @Test
    public void removeBroken() {
        Map map = new Map("src/test/resources/mapTest1.txt");
        map.importMap();
        map.removeBrokenWall(192,80 );
        HashMap<String, int[]> walls = map.getWalls();
        //x is the col aka 32*x
        //y is the row aka 48+32*y
        assertEquals(32,walls.size());
        assertTrue(walls.containsKey("0,80"));
        assertFalse(walls.containsKey("192,80") );
        assertTrue(walls.containsKey("448,80") );
        for( int i=0; i<15;i++){
            assertTrue(walls.containsKey(String.format("%d,%d",i*32,48)));
        }
        for( int i=0; i<15;i++){
            assertTrue(walls.containsKey(String.format("%d,%d",i*32,112)));
        }


    }

    // Testing remove wall doesnt remove solid wall 
    @Test
    public void removeNoBrokenWall() {
        Map map = new Map("src/test/resources/mapTest1.txt");
        map.importMap();
        map.removeBrokenWall(0,80 );
        HashMap<String, int[]> walls = map.getWalls();
        //x is the col aka 32*x
        //y is the row aka 48+32*y
        assertEquals(33,walls.size());
        assertTrue(walls.containsKey("192,80") );
        assertTrue(walls.containsKey("0,80"));

        assertTrue(walls.containsKey("448,80") );
        for( int i=0; i<15;i++){
            assertTrue(walls.containsKey(String.format("%d,%d",i*32,48)));
        }
        for( int i=0; i<15;i++){
            assertTrue(walls.containsKey(String.format("%d,%d",i*32,112)));
        }

    }

   // Test get goal tile=================================================================
   
    @Test
    public void getFinish() {
        Map map = new Map("src/test/resources/mapTest1.txt");
        map.importMap();
        int[] goal= map.getFinish();
        assertEquals(416,goal[0] );
        assertEquals(80,goal[1] );

    }



   // Test get player start method =================================================================
   
    @Test
    public void getPlayer() {
        Map map = new Map("src/test/resources/mapTest1.txt");
        map.importMap();
        tiletypes[][] initial = map.getMapArray();
        int[] playerStart= map.getPlayerStart();
        assertEquals(32,playerStart[0] );
        assertEquals(80,playerStart[1] );

    }

 // Test get enemy start method =================================================================
   
    @Test
    public void getRedEnemiesStart() {
        Map map = new Map("src/test/resources/mapEnemies.txt");
        map.importMap();
        tiletypes[][] initial = map.getMapArray();
        ArrayList<int[]> enemyStart= map.getEnemiesRStart();
        assertEquals(192,enemyStart.get(0)[0]);// Note: cols is x
        assertEquals(80,enemyStart.get(0)[1]); // Note: rows is y 
        assertEquals(224,enemyStart.get(1)[0]);
        assertEquals(80,enemyStart.get(1)[1]);
        assertEquals(288,enemyStart.get(2)[0]);
        assertEquals(144,enemyStart.get(2)[1]);

    }


    @Test
    public void getYellowEnemiesStart() {
        Map map = new Map("src/test/resources/mapEnemies.txt");
        map.importMap();
        tiletypes[][] initial = map.getMapArray();
        ArrayList<int[]> enemyStart= map.getEnemiesYStart();
        assertEquals(384,enemyStart.get(0)[0]);
        assertEquals(80,enemyStart.get(0)[1]);
        assertEquals(416,enemyStart.get(1)[0]);
        assertEquals(80,enemyStart.get(1)[1]);
        assertEquals(256,enemyStart.get(2)[0]);
        assertEquals(144,enemyStart.get(2)[1]);

    }




    // Test gettiletypes=================================================================

 
    @Test
    public void getTiles() {
        Map map = new Map("src/test/resources/mapTest1.txt");
        map.importMap();
        // Get tiels x is columns 32*x
        // get tiles y is rows = 48+y(32)
        assertEquals(tiletypes.solid,map.getTile(0,80) );
        assertEquals(tiletypes.empty,map.getTile(32,80) );
        assertEquals(tiletypes.empty,map.getTile(64,80) );
        assertEquals(tiletypes.empty,map.getTile(96,80));
        assertEquals(tiletypes.empty,map.getTile(128,80) );
        assertEquals(tiletypes.empty,map.getTile(160,80) );
        assertEquals(tiletypes.broken,map.getTile(192,80));
        assertEquals(tiletypes.empty,map.getTile(224,80) );
        assertEquals(tiletypes.empty,map.getTile(256,80) );
        assertEquals(tiletypes.empty,map.getTile(288,80) );
        assertEquals(tiletypes.empty,map.getTile(320,80) );
        assertEquals(tiletypes.empty,map.getTile(352,80) );
        assertEquals(tiletypes.empty,map.getTile(384,80) );
        assertEquals(tiletypes.goal,map.getTile(416,80) );
        assertEquals(tiletypes.solid,map.getTile(448,80) );

    }


    // Tiletypes outside of boundaries 
    @Test
    public void getTilesOutOfRangeA() {
        Map map = new Map("src/test/resources/mapTest1.txt");
        map.importMap();
        assertEquals(tiletypes.solid,map.getTile(-1,-1));
        assertEquals(tiletypes.solid,map.getTile(470,32) );

    }

    // Tiletypes outside of boundaries 
    @Test
    public void getTilesOutOfRangeB() {
        Map map = new Map("src/test/resources/mapTest1.txt");
        map.importMap();
        assertEquals(tiletypes.solid,map.getTile(64,-1));
        assertEquals(tiletypes.solid,map.getTile(64,500) );

    }



}