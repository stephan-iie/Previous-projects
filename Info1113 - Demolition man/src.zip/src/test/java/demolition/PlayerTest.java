package demolition;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.HashMap;
import java.util.ArrayList;


public class PlayerTest {

    
    
    // Test that the constructor positions are correct 
    @Test
    public void constructorTest() {
        Player p = new Player (0,0, 2);
        assertEquals(0, p.getX());
        assertEquals(0, p.getY());
        assertEquals(2, p.getLives());

    }


    // test set loction 
    @Test
    public void changePlayerLocation() {
        Player p = new Player (0,0, 2);
        p.setLocation(4,4);
        assertEquals(4, p.getX());
        assertEquals(4, p.getY());
        assertEquals(2, p.getLives());

    }


    // Test if dead decreases lives
     @Test
    public void playerDied() {
        Player p = new Player (0,0, 2);
        p.dead();
        assertEquals(1, p.getLives());
        p.dead();
        assertEquals(0, p.getLives());
    }

    // Test lives doesnt go negtive 
     @Test
    public void noNegativeLives() {
        Player p = new Player (0,0, 2);
        p.dead();
        p.dead();
        p.dead();
        assertEquals(0, p.getLives());
    }

    // Test if no more lives returns True
    @Test
    public void noMoreLivesTrue() {
        Player p = new Player (0,0, 2);
        p.dead();
        p.dead();
        assertTrue(p.noMoreLives());
    }

    // Test if no more lives returns false
    @Test
    public void noMoreLivesFalse() {
        Player p = new Player (0,0, 2);
        assertFalse(p.noMoreLives());
        p.dead();
        assertFalse(p.noMoreLives());
        p.dead();
    }



    // Test pressleft does nothing when wall
    // animation same as before, 
   
   @Test
    public void dontGoLeft() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>(){{put("0,80", new int[]{0,80});}});
        p.pressLeft();
        p.tick();
        assertEquals(32, p.getX()); // this is the coumns  
        assertEquals(80, p.getY());// this is the rows
        assertEquals("down", p.getAnimationCycle());
    }



    // Test if pressleft DOES occur 
    @Test
    public void goLeft() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>(){{put("32,80", new int[]{32,80});}});
        p.pressLeft();
        p.tick();
        assertEquals(0, p.getX()); // this is the coumns  
        assertEquals(80, p.getY());// this is the rows
        assertEquals("left", p.getAnimationCycle());
    }


    // Test press right  does nothing when walll
    // animation same as before, 
    @Test
    public void dontGoRight() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>(){{put("64,80", new int[]{64,80});}});
        p.pressRight();
        p.tick();
        assertEquals(32, p.getX()); // this is the coumns  
        assertEquals(80, p.getY());// this is the rows
        assertEquals("down", p.getAnimationCycle());
    }

    // Test if press right DOES occur 
    @Test
    public void goRight() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>(){{put("0,80", new int[]{0,80});}});
        p.pressRight();
        p.tick();
        assertEquals(64, p.getX()); // this is the coumns  
        assertEquals(80, p.getY());// this is the rows
        assertEquals("right", p.getAnimationCycle());
    }

    // Test press up  does nothing when wall
    // animation same as before, 
    @Test
    public void dontGoUp() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});}});
        p.pressUp();
        p.tick();
        assertEquals(32, p.getX()); // this is the coumns  
        assertEquals(80, p.getY());// this is the rows
        assertEquals("down", p.getAnimationCycle());
    }

    // Test if press up DOES occur 
    @Test
    public void goUp() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>(){{put("32,112", new int[]{32,112});}});
        p.pressUp();
        p.tick();
        assertEquals(32, p.getX()); // this is the coumns  
        assertEquals(48, p.getY());// this is the rows
        assertEquals("up", p.getAnimationCycle());
    }

    // Test press down  does nothing when wall
    // animation same as before,
    @Test
    public void dontGoDown() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>(){{put("32,112", new int[]{32,112});}});
        p.pressDown();
        p.tick();
        assertEquals(32, p.getX()); // this is the coumns  
        assertEquals(80, p.getY());// this is the rows
        assertEquals("down", p.getAnimationCycle());
    }

    // Test if press down  DOES occur 
    @Test
    public void goDown() {
        Player p = new Player (32,80, 2);
        p.setMapWalls(new HashMap<String, int[]>(){{put("0,48", new int[]{0,48});}});
        p.pressDown();
        p.tick();
        assertEquals(32, p.getX()); // this is the coumns  
        assertEquals(112, p.getY());// this is the rows
        assertEquals("down", p.getAnimationCycle());
    }




}
