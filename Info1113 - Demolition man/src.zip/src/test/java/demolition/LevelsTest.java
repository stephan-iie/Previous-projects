package demolition;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;


public class LevelsTest {
    

    @Test
    public void constructorTest(){

        Levels level = new Levels("src/test/resources/levelsTest.json", null, null);

        // Check the paths are correct
        ArrayList<String> levelPaths = level.getLevelPaths();
        assertEquals("src/test/resources/levelTest1.txt", levelPaths.get(0));
        assertEquals("src/test/resources/levelTest2.txt", levelPaths.get(1));

        // Check the timers is correct 
        ArrayList<Integer> levelTimers = level.getTimers();
        assertEquals(180, levelTimers.get(0));
        assertEquals(90, levelTimers.get(1));

        // Checks the levelNumber is correct
        assertEquals(0,level.getLevelNumber() );

        assertEquals(3,level.getLives() );

    }

    // Level setup- check start, finsh, player notnull, red and yellows not null =================================================================
    @Test
    public void setupTest(){
   
        Levels level = new Levels("src/test/resources/levelsTest.json", null, null);

        // Check initalised player 
        assertNotNull(level.getPlayer());

        // Check intialised in right starting place
        assertEquals(32,level.getPlayer().getX() );
        assertEquals(80,level.getPlayer().getY() );

        // Check correct number of enemies 
        ArrayList<Enemies> levelEnemy= level.getEnemies();
        assertEquals(26,levelEnemy.size());

        // Check enemies are initaised in the right lcoaitons 
        HashMap<String, String> locations = new HashMap<String, String> ();
        for(Enemies enemy: levelEnemy){
            locations.put(String.format("%d,%d", enemy.getX(), enemy.getY()), enemy.getType() );
        }

        for (int i=1;i<14;i++){
            String loc = String.format("%d,%d", 32*i, 208);
            assertTrue(locations.containsKey(loc));
            if(locations.containsKey(loc)){
                assertEquals("Yellow",locations.get(loc));
            }
        }

        for (int i=1;i<14;i++){
            String loc = String.format("%d,%d", 32*i, 304);
            assertTrue(locations.containsKey(loc));
            if(locations.containsKey(loc)){
                assertEquals("Red",locations.get(loc));
            }
        }


    }

    // Level setup- error if no level paths given
    @Test
    public void noLevels(){

        Exception exception = assertThrows(RuntimeException.class, () -> { new Levels("src/test/resources/levelsNoPaths", null, null); });

        String expectedMessage = "Error: File issue";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Level setup- error if timers are not given 
    @Test
    public void noTimers(){

        Exception exception = assertThrows(RuntimeException.class, () -> { new Levels("src/test/resources/levelsNoTimers",  null, null); });

        String expectedMessage = "Error: File issue";
        String actualMessage = exception.getMessage();


        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Level setup- error if timer is negative 
    @Test
    public void negativeTimer(){
  
        
        Exception exception = assertThrows(RuntimeException.class, () -> { new Levels("src/test/resources/negativeTimers.json", null, null); });

        String expectedMessage = "ERROR: Negative timers";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }




    // tick =================================================================

    // Checing enemies killed by bomb -> check if in enemies list (getter function )

    @Test
    public void enemyBombed(){
  
        Levels level = new Levels("src/test/resources/levelsTest.json", null, null);
        Player player = level.getPlayer();

        // Check size of enemies 
        ArrayList<Enemies> levelEnemy= level.getEnemies();
        assertEquals(26,levelEnemy.size());

        player.setLocation(32,368);
        level.placeBomb();

        for(int i =0; i<150; i++){
            level.tick();
            Bomb.removeBomb();        

        }
 
        // Kills 3 in a row since horizontal line 
        assertEquals(23,levelEnemy.size());


    }    

    // Checking player death=================================================================

    // Killed by Enemy - Yellow
    @Test
    public void killedByYellow(){
 
        Levels level = new Levels("src/test/resources/levelsTest.json", null, null);
        Player player = level.getPlayer();
        assertEquals(3, player.getLives());

        player.setLocation(32,240);
        for(int i =0; i<62; i++){
            level.tick();
        }
 
        // Player reset to start location 
        assertEquals(32, player.getX());
        assertEquals(80, player.getY());
        
        // Player life decreased 
        assertEquals(2, player.getLives());
    }    

    // Killed by Enemy - Red
    @Test
    public void killedByRed(){
  
        Levels level = new Levels("src/test/resources/levelsTest.json", null, null);
        Player player = level.getPlayer();
        assertEquals(3, player.getLives());

        player.setLocation(32,336);
        for(int i =0; i<62; i++){
            level.tick();

        }
 
        // Player reset to start location 
        assertEquals(32, player.getX());
        assertEquals(80, player.getY());
        
        // Player life decreased 
        assertEquals(2, player.getLives());

    }    

    // Checking player killed by bomb -> check player lives decrease 
    @Test
    public void suicidalPlayer(){

        Levels level = new Levels("src/test/resources/levelsTest.json", null, null);
        Player player = level.getPlayer();
        assertEquals(3, player.getLives());

        // Moves to the right by 4 = 160
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        assertEquals(0,Bomb.getBombs().size());

        level.placeBomb();


        for(int i=0;i<150;i++){
            level.tick();
            Bomb.removeBomb();
        }

        // Need to remove bomb here since usually in draw (draw then remove exploded bombs )

        // Player reset to start location 
        assertEquals(32, player.getX());
        assertEquals(80, player.getY());
        
        // Player life decreased 
        assertEquals(2, player.getLives());

        // Bomb detonated (should no longer show on level bombs )
        assertEquals(0,Bomb.getBombs().size());

    }

    // Checking player avoids bomb area
    @Test
    public void suicideAvoided(){
        ArrayList<String> paths = new ArrayList<String>();
        paths.add("src/test/resources/levelTest1.txt");
        paths.add("src/test/resources/levelTest2.txt");
        ArrayList<Integer> timers = new ArrayList<Integer>();
        timers.add(Integer.parseInt("180") );
        timers.add(Integer.parseInt("90"));
        Levels level = new Levels("src/test/resources/levelsTest.json", null, null);
        Player player = level.getPlayer();
        assertEquals(3, player.getLives());

        // Moves to the right 
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        assertEquals(0,Bomb.getBombs().size());

        level.placeBomb();

        // Moves player to the left 
        player.pressLeft();
        level.tick();
        player.pressLeft();
        level.tick();
        player.pressLeft();
        level.tick();
        player.pressLeft();
        level.tick();
        player.pressLeft();
        level.tick();
        player.pressLeft();
        level.tick();

        for(int i=0;i<150;i++){
            level.tick();
            Bomb.removeBomb();
        }

        // Need to remove bomb here since usually in draw (draw then remove exploded bombs )

        // Player reset to start location 
        assertEquals(32, player.getX());
        assertEquals(80, player.getY());
        
        // Player life decreased 
        assertEquals(3, player.getLives());

        // Bomb detonated (should no longer show on level bombs )
        assertEquals(0,Bomb.getBombs().size());

    }



    // reduce till no more livses + check gameover  =================================================================
    // Checking player killed by bomb -> check player lives decrease 
    @Test
    public void deathBySuicide(){
  
        Levels level = new Levels("src/test/resources/levelsTest.json", null, null);
        Player player = level.getPlayer();
        assertEquals(3, player.getLives());

        for( int j=0; j<3; j++){ 
            // Moves to the right by 4 = 160
            player.pressRight();
            level.tick();
            player.pressRight();
            level.tick();
            player.pressRight();
            level.tick();
            player.pressRight();
            level.tick();
            player.pressRight();
            level.tick();
            player.pressRight();
            level.tick();
            assertEquals(0,Bomb.getBombs().size());

            level.placeBomb();


            for(int i=0;i<150;i++){
                level.tick();
                Bomb.removeBomb();
            }
        }

        // Player life decreased 
        assertEquals(0, player.getLives());

        // Bomb detonated (should no longer show on level bombs )
        assertEquals(0,Bomb.getBombs().size());


        assertTrue(level.getGameOver());

    }

    // Checking bomb placed and in location of player =================================================================
    @Test
    public void bombPlaced(){
        ArrayList<String> paths = new ArrayList<String>();
        paths.add("src/test/resources/levelTest1.txt");
        paths.add("src/test/resources/levelTest2.txt");
        ArrayList<Integer> timers = new ArrayList<Integer>();
        timers.add(Integer.parseInt("180") );
        timers.add(Integer.parseInt("90"));
        Levels level = new Levels("src/test/resources/levelsTest.json", null, null);
        Player player = level.getPlayer();

        // Moves to the right by 4 = 160
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        player.pressRight();
        level.tick();
        assertEquals(0,Bomb.getBombs().size());

        level.placeBomb();

        // Check right location for bomb 
        assertEquals(1,Bomb.getBombs().size());
        assertEquals(player.getX(),Bomb.getBombs().get(0).getX());
        assertEquals(player.getY(),Bomb.getBombs().get(0).getY());

        // To reset for later
        for(int i=0;i<180;i++){
            level.tick();
            Bomb.removeBomb();
        }


        assertEquals(0,Bomb.getBombs().size());


    }



    // Checking finish level =================================================================
    // game win: player moves right to finish for 2 levels and compeltes the game 
    @Test
    public void teleportedWinDouble(){
        ArrayList<String> paths = new ArrayList<String>();
        paths.add("src/test/resources/levelTest1.txt");
        paths.add("src/test/resources/levelTest2.txt");

        ArrayList<Integer> timers = new ArrayList<Integer>();
        timers.add(Integer.parseInt("180") );
        timers.add(Integer.parseInt("90"));
        Levels level = new Levels("src/test/resources/levelsTest.json", null, null);
        Player player = level.getPlayer();

        player.setLocation(416,400);
        level.tick();
        level.tick();
        assertFalse(level.getGameWin());
        assertEquals(1, level.getLevelNumber());

        System.out.println(Arrays.toString(level.getFinish()));
        Player player2 = level.getPlayer();
        player2.setLocation(416,272);

        level.tick();
 
        assertEquals(2, level.getLevelNumber());

        assertTrue(level.getGameWin());

    }    


    // game win: player moves right and finighes level withh 1 level after 
        @Test
    public void teleportedWin(){
        ArrayList<String> paths = new ArrayList<String>();
        paths.add("src/test/resources/levelTest1.txt");
        ArrayList<Integer> timers = new ArrayList<Integer>();
        timers.add(Integer.parseInt("180") );
        
        Levels level = new Levels("src/test/resources/levelsTestOne.json", null, null);
        Player player = level.getPlayer();

        player.setLocation(416,400);
        level.tick();

        level.tick();
        assertTrue(level.getGameWin());


    }    



}
