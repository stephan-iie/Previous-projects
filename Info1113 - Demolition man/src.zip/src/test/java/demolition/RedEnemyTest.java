package demolition;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.HashMap;

public class RedEnemyTest {
    
    @Test
    public void constructorTest() {
        RedEnemy red = new RedEnemy(32, 80);
        assertEquals(32, red.getX());
        assertEquals(80, red.getY());
        assertFalse(red.enemyKilled());
    }



    // Checking tick=================================================================


    // Checking enemy killed
    @Test
    public void killEnemyTest() {
        RedEnemy red = new RedEnemy(32, 80);
        assertFalse(red.enemyKilled());
        red.killEnemy();
        assertTrue(red.enemyKilled());

    }


    // Continue going straight  if no wall 
    @Test
    public void continueStraight() {
        RedEnemy red = new RedEnemy(32, 80);
        red.setMapWalls(new HashMap<String, int[]>());
        String currentDirection = red.getAnimationCycle();
        red.tick();
        assertEquals(currentDirection, red.getAnimationCycle());
    }

    // Check must go back to where they came from
    // Check can only go left
    @Test
    public void goLeft() {
        RedEnemy red = new RedEnemy(32, 80); // direction always starts down 
        red.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("64,80", new int[]{64,80});}});
        red.tick();
        assertEquals("left", red.getAnimationCycle());
        for(int i=0; i<60; i++){ // it takes 60 ticks for it to move 
            red.tick();
        }
        assertEquals(0, red.getX()); // this is the coumns  
        assertEquals(80, red.getY());// this is the rows
    }

    // Check can only go right 
    @Test
    public void goRight() {
        RedEnemy red = new RedEnemy(32, 80); // direction always starts down 
        red.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("0,80", new int[]{0,80});}});
        red.tick();
        assertEquals("right", red.getAnimationCycle());
        for(int i=0; i<60; i++){ // it takes 60 ticks for it to move 
            red.tick();
        }
        assertEquals(64, red.getX()); // this is the coumns  
        assertEquals(80, red.getY());// this is the rows
    }

    // Check can only go up
    @Test
    public void goUp() {
        RedEnemy red = new RedEnemy(32, 80); // direction always starts down 
        red.setMapWalls(new HashMap<String, int[]>(){{put("64,80", new int[]{64,80});
                                                    put("32,112", new int[]{32,112});
                                                    put("0,80", new int[]{64,80});}});
        red.tick();
        assertEquals("up", red.getAnimationCycle());
        for(int i=0; i<60; i++){ // it takes 60 ticks for it to move 
            red.tick();
        }
        assertEquals(32, red.getX()); // this is the coumns  
        assertEquals(48, red.getY());// this is the rows
    }
    // Check can only go down 
   @Test
    public void goDown() {
        RedEnemy red = new RedEnemy(32, 80); // direction always starts down 
        red.setMapWalls(new HashMap<String, int[]>(){{put("64,80", new int[]{64,80});
                                                    put("32,48", new int[]{32,48});
                                                    put("0,80", new int[]{64,80});}});
        red.tick();
        assertEquals("down", red.getAnimationCycle());
        for(int i=0; i<60; i++){ // it takes 60 ticks for it to move 
            red.tick();
        }
        assertEquals(32, red.getX()); // this is the coumns  
        assertEquals(112, red.getY());// this is the rows
    }

    // Check can only go right left or right or up
   @Test
    public void chooseDirections() {
        RedEnemy red = new RedEnemy(32, 80); // direction always starts down 
        red.setMapWalls(new HashMap<String, int[]>(){{put("32,112", new int[]{32,112});}});
        red.tick();
        assertTrue(red.getAnimationCycle()=="up" ||red.getAnimationCycle()=="left"|| red.getAnimationCycle()=="right");
    }

    // Check can only go up down , or up
    @Test
    public void chooseDirection2() {
        RedEnemy red = new RedEnemy(32, 80); // direction always starts down 
        red.setMapWalls(new HashMap<String, int[]>(){{put("32,48", new int[]{32,48});
                                                    put("32,112", new int[]{32,112});
                                                    put("96,80", new int[]{96,80});
                                                    put("0,80", new int[]{0,80});}});
        red.tick();
        assertEquals("right", red.getAnimationCycle());
        for(int i=0; i<60; i++){ // it takes 60 ticks for it to move 
            red.tick();
        }
        assertEquals(64, red.getX()); // this is the coumns  
        assertEquals(80, red.getY());// this is the rows
        red.tick();
        assertTrue(red.getAnimationCycle()=="down" || red.getAnimationCycle()=="up"|| red.getAnimationCycle()=="left" );


    }



}
